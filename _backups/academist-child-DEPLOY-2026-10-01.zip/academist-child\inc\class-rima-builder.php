<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Rima_Builder {
    public function __construct() {
        add_action( 'init', array( $this, 'register_post_type' ) );
        add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
    }

    public function register_post_type() {
        $labels = array(
            'name'               => 'Rima Templates',
            'singular_name'      => 'Template',
            'menu_name'          => 'Rima Templates',
            'add_new'            => 'Adaugă Template',
            'add_new_item'       => 'Adaugă Template Nou',
            'edit_item'          => 'Editează Template',
            'new_item'           => 'Template Nou',
            'view_item'          => 'Vezi Template',
            'all_items'          => 'Toate Template-urile',
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true, // needs to be true so WPBakery can render frontend
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'rima-template' ),
            'capability_type'    => 'post',
            'has_archive'        => false,
            'hierarchical'       => false,
            'menu_position'      => 58,
            'menu_icon'          => 'dashicons-layout',
            'supports'           => array( 'title', 'editor' ),
        );

        register_post_type( 'rima_template', $args );
    }

    public function add_settings_page() {
        add_submenu_page(
            'edit.php?post_type=rima_template',
            'Setări Header & Footer',
            'Setări Builder',
            'manage_options',
            'rima_builder_settings',
            array( $this, 'render_settings_page' )
        );
    }

    public function register_settings() {
        register_setting( 'rima_builder_options', 'rima_header_template_id' );
        register_setting( 'rima_builder_options', 'rima_footer_template_id' );
    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>Setări Header & Footer (Rima Builder)</h1>
            <p>Selectează template-urile create mai sus pe care dorești să le afișezi ca Header și Footer global.</p>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'rima_builder_options' );
                do_settings_sections( 'rima_builder_options' );
                
                // Get all templates
                $templates = get_posts( array(
                    'post_type' => 'rima_template',
                    'numberposts' => -1,
                    'post_status' => 'publish'
                ) );
                ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Header Template</th>
                        <td>
                            <select name="rima_header_template_id">
                                <option value="">-- Niciunul (Folosește default) --</option>
                                <?php foreach ( $templates as $tpl ) : ?>
                                    <option value="<?php echo esc_attr( $tpl->ID ); ?>" <?php selected( get_option('rima_header_template_id'), $tpl->ID ); ?>>
                                        <?php echo esc_html( $tpl->post_title ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Footer Template</th>
                        <td>
                            <select name="rima_footer_template_id">
                                <option value="">-- Niciunul (Folosește default) --</option>
                                <?php foreach ( $templates as $tpl ) : ?>
                                    <option value="<?php echo esc_attr( $tpl->ID ); ?>" <?php selected( get_option('rima_footer_template_id'), $tpl->ID ); ?>>
                                        <?php echo esc_html( $tpl->post_title ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}
new Rima_Builder();
