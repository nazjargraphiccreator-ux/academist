<?php
/**
 * Academist Child Theme â€” functions.php
 * RIMA Academy Professional Dashboard
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── RIMA Email Notification System ────────────────────────────
require_once get_stylesheet_directory() . '/inc/rima-email-notifications.php';

// ── RIMA Secure PDF Tracker ────────────────────────────
require_once get_stylesheet_directory() . '/inc/pdf-server.php';
require_once get_stylesheet_directory() . '/inc/product-meta.php';
require_once get_stylesheet_directory() . '/inc/rima-pricing-ajax.php';

// ── RIMA B2B Checkout Logic ────────────────────────────
require_once get_stylesheet_directory() . '/inc/rima-b2b-checkout.php';

// Unhook Academist defaults that conflict - use template_redirect for correct timing
add_action('wp', 'rima_remove_academist_annoyances', 1);
function rima_remove_academist_annoyances() {
    // Remove parent theme's mobile header (always - we have our own)
    remove_action('academist_elated_action_after_body_tag', 'academist_elated_get_mobile_header', 10);
    remove_action('academist_elated_action_after_header_area', 'academist_elated_get_mobile_header', 10);
    // Remove parent theme's title on our courses page
    remove_action('academist_elated_action_after_header_area', 'academist_elated_get_title', 20);
}

// Also hook earlier (wp_loaded) as a belt-and-suspenders approach
add_action('wp_loaded', 'rima_remove_academist_annoyances_early', 1);
function rima_remove_academist_annoyances_early() {
    remove_action('academist_elated_action_after_body_tag', 'academist_elated_get_mobile_header', 10);
    remove_action('academist_elated_action_after_header_area', 'academist_elated_get_mobile_header', 10);
}

// ── RIMA Header & Footer Builder ────────────────────────────
require_once get_stylesheet_directory() . '/inc/class-rima-builder.php';

// Force WPBakery to enable on our new Template Post Type
add_action( 'init', 'rima_enable_vc_for_templates' );
function rima_enable_vc_for_templates() {
    if ( function_exists('vc_set_default_editor_post_types') ) {
        $list = get_option( 'wpb_js_content_types' );
        if ( ! is_array( $list ) ) {
            $list = array( 'page', 'post' );
        }
        if ( ! in_array( 'rima_template', $list ) ) {
            $list[] = 'rima_template';
            update_option( 'wpb_js_content_types', $list );
        }
    }
}

// ── RIMA Modern Cart & Checkout CSS ────────────────────────────
add_action( 'wp_enqueue_scripts', 'rima_enqueue_modern_checkout_css', 999 );
function rima_enqueue_modern_checkout_css() {
    if ( class_exists( 'WooCommerce' ) ) {
        if ( is_cart() || is_checkout() || is_account_page() ) {
            wp_enqueue_style(
                'rima-cart-checkout-modern',
                get_stylesheet_directory_uri() . '/assets/css/rima-cart-checkout-modern.css',
                array(),
                '2026.2'
            );
        }
    }
}

// ── RIMA 2026 Design System Enqueue ────────────────────────────
add_action( 'wp_enqueue_scripts', 'rima_enqueue_design_system', 10 );
function rima_enqueue_design_system() {
    // Core Tokens & Typography
    wp_enqueue_style(
        'rima-global-tokens',
        get_stylesheet_directory_uri() . '/assets/css/global.css',
        array(),
        '2026.4'
    );
    
    // UI Components Library
    wp_enqueue_style(
        'rima-components',
        get_stylesheet_directory_uri() . '/assets/css/components.css',
        array('rima-global-tokens'),
        '2026.4'
    );

    // Header Styles
    wp_enqueue_style(
        'rima-header',
        get_stylesheet_directory_uri() . '/assets/css/header.css',
        array('rima-global-tokens', 'rima-components'),
        '2026.4'
    );

    // Footer Styles
    wp_enqueue_style(
        'rima-footer',
        get_stylesheet_directory_uri() . '/assets/css/footer.css',
        array('rima-global-tokens'),
        '2026.4'
    );
}

/* ============================================================
   0. FORCE CLASSIC CART & CHECKOUT (disable Gutenberg Blocks)
   ============================================================ */
add_filter( 'woocommerce_cart_page_allow_shortcode',     '__return_true' );
add_filter( 'woocommerce_checkout_page_allow_shortcode', '__return_true' );

// Disable WooCommerce Block Cart and Block Checkout
add_filter( 'woocommerce_feature_wc_blocks_enabled', '__return_false' );
add_filter( 'has_block', function( $has_block, $block_name, $post ) {
    if ( in_array( $block_name, array( 'woocommerce/cart', 'woocommerce/checkout' ), true ) ) {
        return false;
    }
    return $has_block;
}, 10, 3 );

// Add body class so our CSS can target the pages
add_filter( 'body_class', function( $classes ) {
    if ( is_cart() )     $classes[] = 'rima-cart-page';
    if ( is_checkout() ) $classes[] = 'rima-checkout-page';
    
    // Global server-side language state
    if ( is_user_logged_in() ) {
        $lang_pref = get_user_meta( get_current_user_id(), '_rima_lang_pref', true );
        if ( $lang_pref === 'ro' ) {
            $classes[] = 'rima-lang-ro';
        }
    }
    
    return $classes;
} );

add_action( 'init', 'rima_force_enable_vc_for_lms' );
function rima_force_enable_vc_for_lms() {
    // 1. Force via DB option for existing installations
    $current = get_option('wpb_js_content_types');
    if ( ! is_array($current) ) {
        $current = array('page', 'post');
    }
    
    $lms_types = array('course', 'lesson', 'quiz', 'question');
    $updated = false;
    foreach ( $lms_types as $pt ) {
        if ( ! in_array( $pt, $current ) ) {
            $current[] = $pt;
            $updated = true;
        }
    }
    if ( $updated ) {
        update_option( 'wpb_js_content_types', $current );
    }
}

// 2. Set defaults via WPBakery API
add_action( 'vc_before_init', function() {
    if ( function_exists( 'vc_set_default_editor_post_types' ) ) {
        vc_set_default_editor_post_types( array( 'page', 'post', 'course', 'lesson', 'quiz', 'question' ) );
    }
});


/* ============================================================
   0.2 BILINGUAL CHECKOUT & ADDRESS FIELDS (EN / RO)
   ============================================================ */
add_filter( 'woocommerce_default_address_fields', 'rima_bilingual_address_fields', 999 );
function rima_bilingual_address_fields( $fields ) {
    $translations = array(
        'first_name' => 'Prenume',
        'last_name'  => 'Nume de familie',
        'company'    => 'Companie (opțional)',
        'country'    => 'Țară / Regiune',
        'address_1'  => 'Adresă stradală',
        'address_2'  => 'Apartament, suită, unitate etc. (opțional)',
        'city'       => 'Localitate / Oraș',
        'state'      => 'Județ / Sector',
        'postcode'   => 'Cod poștal',
    );
    foreach ( $fields as $key => $field ) {
        if ( isset( $translations[ $key ] ) ) {
            $en_label = isset($fields[ $key ]['label']) ? $fields[ $key ]['label'] : '';
            $ro_label = $translations[ $key ];
            $fields[ $key ]['label'] = '<span class="rima-en">' . $en_label . '</span><span class="rima-ro">' . $ro_label . '</span>';
        }
    }
    return $fields;
}

// Enable SVG Support
function rima_add_svg_support($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'rima_add_svg_support');

// Remove generic lorem ipsum from academist-lms reviews
add_filter('gettext', 'rima_remove_lorem_ipsum_reviews', 10, 3);
function rima_remove_lorem_ipsum_reviews($translated_text, $text, $domain) {
    if ($domain === 'academist-lms') {
        if (strpos($text, 'Lorem Ipsn gravida nibh vel') !== false) {
            return '';
        }
    }
    return $translated_text;
}

// Force comments open for courses so the review form or warning message is always displayed
add_filter( 'comments_open', 'rima_force_course_comments_open', 10, 2 );
function rima_force_course_comments_open( $open, $post_id ) {
    if ( get_post_type( $post_id ) === 'course' ) {
        return true;
    }
    return $open;
}

// Backend protection: block review submission if user is not enrolled
add_filter( 'preprocess_comment', 'rima_restrict_course_comments_backend' );
function rima_restrict_course_comments_backend( $commentdata ) {
    $post_id = $commentdata['comment_post_ID'];
    if ( get_post_type( $post_id ) === 'course' ) {
        if ( ! is_user_logged_in() || ! function_exists( 'academist_lms_user_has_course' ) || ! academist_lms_user_has_course( $post_id ) ) {
            wp_die( __( 'You must be enrolled in this course to leave a review.', 'academist-child' ) );
        }
    }
    return $commentdata;
}

add_filter( 'woocommerce_billing_fields', 'rima_bilingual_billing_fields', 999 );
function rima_bilingual_billing_fields( $fields ) {
    $translations = array(
        'billing_phone' => 'Telefon',
        'billing_email' => 'Adresă de email',
    );
    foreach ( $fields as $key => $field ) {
        if ( isset( $translations[ $key ] ) ) {
            $en_label = isset($fields[ $key ]['label']) ? $fields[ $key ]['label'] : '';
            $ro_label = $translations[ $key ];
            $fields[ $key ]['label'] = '<span class="rima-en">' . $en_label . '</span><span class="rima-ro">' . $ro_label . '</span>';
        }
    }
    return $fields;
}

/* ============================================================
   1. ENQUEUE STYLES & SCRIPTS
   ============================================================ */
if ( ! function_exists( 'academist_elated_child_theme_enqueue_scripts' ) ) {

	function academist_elated_child_theme_enqueue_scripts() {
		$parent_style = 'academist-elated-default-style';
		wp_enqueue_style( 'academist-elated-child-style', get_stylesheet_directory_uri() . '/style.css', array( $parent_style ) );

		// Register and enqueue RIMA Design System globally to support the side cart on all pages
		$design_system_deps = array();
		if ( class_exists( 'WooCommerce' ) && ( is_account_page() || is_cart() || is_checkout() ) ) {
			wp_enqueue_style(
				'bootstrap-5',
				'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css',
				array(),
				'5.3.3'
			);
			$design_system_deps[] = 'bootstrap-5';
		}

		wp_enqueue_style(
			'rima-design-system',
			get_stylesheet_directory_uri() . '/assets/css/rima-design-system.css',
			$design_system_deps,
			'2.0.0'
		);

		// 2026 Premium Redesign Styles
		wp_enqueue_style(
			'rima-2026-premium',
			get_stylesheet_directory_uri() . '/assets/css/rima-2026-premium.css',
			array('rima-design-system'),
			'1.0.0'
		);

		// Home Page 2026 CSS
		if ( is_front_page() || is_home() || is_page_template( 'page-home-modern.php' ) ) {
			wp_enqueue_style(
				'rima-home-style',
				get_stylesheet_directory_uri() . '/assets/css/rima-home-2026.css',
				array( 'rima-design-system' ),
				'1.0.0'
			);
		}

		// Dashboard CSS & other conditional styles
		if ( class_exists( 'WooCommerce' ) && ( is_account_page() || is_cart() || is_checkout() ) ) {
            if ( is_account_page() ) {
                wp_enqueue_style(
                    'rima-dashboard-style',
                    get_stylesheet_directory_uri() . '/assets/css/dashboard-style.css',
                    array('bootstrap-5'),
                    '2.0.0'
                );

                // Localize script for AJAX avatar upload
                wp_localize_script( 'jquery', 'rima_ajax_obj', array(
                    'ajax_url' => admin_url( 'admin-ajax.php' ),
                    'nonce'    => wp_create_nonce( 'rima_nonce' )
                ) );
            }
            
            if ( is_cart() ) {
                wp_enqueue_style(
                    'rima-cart-style',
                    get_stylesheet_directory_uri() . '/assets/css/rima-cart.css',
                    array('rima-design-system'),
                    '2.0.0'
                );
            }
            
            if ( is_checkout() ) {
                wp_enqueue_style(
                    'rima-checkout-style',
                    get_stylesheet_directory_uri() . '/assets/css/rima-checkout.css',
                    array('rima-design-system'),
                    '2.0.0'
                );
            }
            
            // Romanian Cities Dropdown for Checkout and Edit Address
            if ( is_checkout() || is_account_page() ) {
                wp_enqueue_script(
                    'rima-romanian-cities',
                    get_stylesheet_directory_uri() . '/assets/js/romanian-cities.js',
                    array('jquery'),
                    '1.0.0',
                    true
                );
                wp_localize_script( 'rima-romanian-cities', 'romanianCitiesObj', array(
                    'jsonUrl' => get_stylesheet_directory_uri() . '/inc/romanian-cities.json'
                ) );
            }
		}

        // Contact Page CSS — load only on the page that uses the "Rima Academy – Contact Page" template
        if ( is_page_template( 'page-contact.php' ) ) {
            wp_enqueue_style(
                'rima-contact-style',
                get_stylesheet_directory_uri() . '/assets/css/rima-contact.css',
                array( 'rima-design-system' ),
                time()
            );
        }

        // Single Course CSS & JS
        if ( is_singular( 'course' ) ) {
            wp_enqueue_style(
                'rima-single-course-style',
                get_stylesheet_directory_uri() . '/assets/css/rima-single-course.css',
                array( 'rima-design-system' ),
                '1.0.0'
            );
            wp_enqueue_script(
                'rima-single-course-script',
                get_stylesheet_directory_uri() . '/assets/js/rima-single-course.js',
                array( 'jquery' ),
                '1.0.0',
                true
            );
        }

        // Our Courses CSS & JS
        if ( is_post_type_archive( 'course' ) || is_page_template( 'page-our-courses.php' ) || is_page( 'our-courses' ) || is_page( 'cursuri' ) ) {
            wp_enqueue_style(
                'rima-courses-style',
                get_stylesheet_directory_uri() . '/assets/css/rima-courses.css',
                array( 'rima-design-system' ),
                time()
            );
            wp_enqueue_script(
                'rima-courses-script',
                get_stylesheet_directory_uri() . '/assets/js/rima-courses.js',
                array( 'jquery' ),
                '1.0.0',
                true
            );
        }
	}
	add_action( 'wp_enqueue_scripts', 'academist_elated_child_theme_enqueue_scripts', 20 );
}

/**
 * RIMA LOGIN PAGE — MOBILE APP LAYOUT
 * Injected via wp_head with priority 999 (after all theme CSS) so it wins on mobile.
 * Only runs on the My Account page when user is not logged in.
 */
add_action( 'wp_head', function() {
    if ( ! function_exists('is_account_page') || ! is_account_page() ) return;
    if ( is_user_logged_in() ) return;
    ?>
    <style id="rima-login-mobile-css">
    /* ============================================================
       RIMA LOGIN — MOBILE APP LAYOUT  (≤ 640px)
       Loaded in <head> via wp_head priority 999 — beats all theme CSS
       ============================================================ */
    @media screen and (max-width: 640px) {

        /* 1. Hide theme header + mobile nav bar on login page */
        body.woocommerce-account:not(.logged-in) header,
        body.woocommerce-account:not(.logged-in) .eltdf-page-header,
        body.woocommerce-account:not(.logged-in) .eltdf-mobile-header,
        body.woocommerce-account:not(.logged-in) #header,
        body.woocommerce-account:not(.logged-in) .site-header,
        body.woocommerce-account:not(.logged-in) nav.eltdf-mobile-header,
        body.woocommerce-account:not(.logged-in) .eltdf-sticky-header,
        body.woocommerce-account:not(.logged-in) .eltdf-top-bar,
        body.woocommerce-account:not(.logged-in) .footer-widgets-area,
        body.woocommerce-account:not(.logged-in) footer,
        body.woocommerce-account:not(.logged-in) .eltdf-page-footer,
        body.woocommerce-account:not(.logged-in) [class*="mobile-nav"],
        body.woocommerce-account:not(.logged-in) [class*="bottom-bar"] {
            display: none !important;
        }

        /* 2. Body removes default padding WordPress/theme adds for admin bar etc */
        body.woocommerce-account:not(.logged-in) {
            padding-top: 0 !important;
            margin-top: 0 !important;
        }

        /* 3. Full-screen page layout */
        body.woocommerce-account:not(.logged-in) .rima-login-page,
        body.woocommerce-account:not(.logged-in) .rima-login-page.rima-immersive-layout {
            display: block !important;
            min-height: 100vh !important;
            overflow-y: auto !important;
            overflow-x: hidden !important;
            padding: 0 !important;
            margin: 0 !important;
            width: 100vw !important;
            align-items: unset !important;
            justify-content: unset !important;
        }

        /* 4. Globe more subtle */
        body.woocommerce-account:not(.logged-in) #rhm-globe-viz,
        body.woocommerce-account:not(.logged-in) .rima-fullscreen-globe {
            opacity: 0.15 !important;
        }

        /* 5. Wrapper — full width, stretch */
        body.woocommerce-account:not(.logged-in) .rima-centered-wrapper {
            max-width: 100vw !important;
            width: 100vw !important;
            padding: 0 !important;
            min-height: 100vh !important;
            display: flex !important;
            flex-direction: column !important;
            align-items: stretch !important;
            box-sizing: border-box !important;
        }

        /* 6. Card fills full screen */
        body.woocommerce-account:not(.logged-in) .rima-lp-card {
            flex: 1 1 auto !important;
            width: 100% !important;
            max-width: 100% !important;
            border-radius: 0 !important;
            border-left: none !important;
            border-right: none !important;
            border-bottom: none !important;
            border-top: 1px solid rgba(255,255,255,0.1) !important;
            box-shadow: none !important;
            background: rgba(6, 8, 18, 0.96) !important;
            backdrop-filter: blur(30px) !important;
            -webkit-backdrop-filter: blur(30px) !important;
            margin: 0 !important;
            box-sizing: border-box !important;
        }

        /* 7. App navbar header */
        body.woocommerce-account:not(.logged-in) .rima-card-header {
            position: sticky !important;
            top: 0 !important;
            z-index: 9999 !important;
            padding: 12px 20px !important;
            background: rgba(4, 6, 14, 0.98) !important;
            backdrop-filter: blur(30px) !important;
            -webkit-backdrop-filter: blur(30px) !important;
            border-bottom: 1px solid rgba(255,255,255,0.09) !important;
            display: flex !important;
            align-items: center !important;
            justify-content: space-between !important;
            box-sizing: border-box !important;
        }

        body.woocommerce-account:not(.logged-in) .rima-card-logo {
            display: none !important;
        }

        /* 8. Back badge compact - left aligned since logo is hidden */
        body.woocommerce-account:not(.logged-in) .rima-back-badge {
            font-size: 0.72rem !important;
            padding: 4px 10px 4px 8px !important;
            gap: 4px !important;
        }

        /* 9. Card body */
        body.woocommerce-account:not(.logged-in) .rima-card-body {
            padding: 20px 20px 40px !important;
        }

        /* 10. Inputs larger for touch */
        body.woocommerce-account:not(.logged-in) .rima-lp-input {
            padding: 14px 16px !important;
            font-size: 16px !important; /* prevents iOS zoom */
            border-radius: 10px !important;
        }

        /* 11. Submit full width */
        body.woocommerce-account:not(.logged-in) .rima-lp-submit {
            width: 100% !important;
            padding: 15px !important;
            font-size: 1rem !important;
            border-radius: 12px !important;
            margin-top: 8px !important;
        }

        /* 12. Tabs full width */
        body.woocommerce-account:not(.logged-in) .rima-lp-tabs {
            margin-bottom: 20px !important;
        }
        body.woocommerce-account:not(.logged-in) .rima-lp-tab {
            font-size: 0.78rem !important;
            padding: 10px 8px !important;
        }

        /* 13. Hide card top accent */
        body.woocommerce-account:not(.logged-in) .rima-lp-card::before {
            display: none !important;
        }
    }
    </style>
    <?php
}, 999 );

/**
 * 1d_bis. RIMA IFRAME SPA MODE
 * Hides headers, footers, and sidebars when loading a lesson in the dashboard SPA iframe
 */
add_action('wp_head', function() {
    if ( isset($_GET['rima_iframe']) && $_GET['rima_iframe'] === '1' ) {
        echo '<style>
            /* Hide all standard theme wrappers and navigation */
            header, footer, .eltdf-page-header, .eltdf-mobile-header, .eltdf-page-footer, .eltdf-title-holder, .eltdf-sidebar, .eltdf-top-bar, .eltdf-bottom-bar, #wpadminbar { display: none !important; }
            
            /* Reset body padding/margins */
            body, html { padding: 0 !important; margin: 0 !important; height: 100vh; overflow-y: auto; background: #f8f9fa !important; }
            .eltdf-wrapper, .eltdf-wrapper-inner, .eltdf-content, .eltdf-content-inner { padding: 0 !important; margin: 0 !important; }
            
            /* Lesson specific fixes */
            .eltdf-lesson-single-holder { margin-top: 0 !important; padding: 20px !important; }
            .eltdf-grid-row { display: block !important; margin: 0 !important; }
            .eltdf-page-content-holder { width: 100% !important; padding: 0 !important; }
        </style>';
    }
}, 999);

/* ============================================================
   1e. WPBAKERY — Forțează assets + shortcodes global
   ============================================================
   Permite shortcode-urile WPBakery (inclusiv static blocks) să
   funcționeze pe orice template PHP, nu doar pe paginile editate
   cu WPBakery. Necesar pentru footer/header din Static Blocks.
   ============================================================ */

// 1) Încarcă CSS-ul WPBakery pe toate paginile frontend
add_action( 'wp_enqueue_scripts', function() {
    if ( class_exists( 'Vc_Manager' ) ) {
        wp_enqueue_style( 'js_composer_front' );
        wp_enqueue_style( 'js_composer_custom_css' );
    }
}, 30 );

// 2) Încarcă JS-ul WPBakery pe toate paginile frontend
add_action( 'wp_enqueue_scripts', function() {
    if ( class_exists( 'Vc_Manager' ) ) {
        wp_enqueue_script( 'wpb_composer_front_js' );
    }
}, 30 );

// 3) Înregistrează Post Type 'static_block' pentru ca userul să aibă meniul "Static Blocks" înapoi
add_action( 'init', 'rima_register_static_blocks_cpt' );
function rima_register_static_blocks_cpt() {
    register_post_type( 'static_block', array(
        'labels' => array(
            'name'          => 'Static Blocks',
            'singular_name' => 'Static Block',
            'menu_name'     => 'Static Blocks',
            'all_items'     => 'All Static Blocks',
            'add_new'       => 'Add New',
            'add_new_item'  => 'Add New Static Block',
            'edit_item'     => 'Edit Static Block',
            'new_item'      => 'New Static Block',
            'view_item'     => 'View Static Block',
        ),
        'public'              => true,
        'exclude_from_search' => true,
        'publicly_queryable'  => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'menu_icon'           => 'dashicons-layout',
        'supports'            => array( 'title', 'editor', 'revisions' ),
    ) );
}

// 4) Forțează WPBakery să se activeze pe post type-ul 'static_block' implicit
// 4) Force WPBakery in DB options so the editor appears for the user
add_action( 'admin_init', function() {
    $pt = get_option( 'wpb_js_content_types' );
    if ( ! is_array( $pt ) ) {
        $pt = array( 'page', 'post' );
    }
    if ( ! in_array( 'static_block', $pt ) ) {
        $pt[] = 'static_block';
        update_option( 'wpb_js_content_types', $pt );
    }
} );

// 5) Helper: randează un Static Block WPBakery după slug
//    Folosire în template: rima_static_block( 'footer' );
if ( ! function_exists( 'rima_static_block' ) ) {
    function rima_static_block( $slug, $echo = true ) {
        // Caută post-ul de tip 'static_block' cu slug-ul dat
        $post = get_page_by_path( $slug, OBJECT, 'static_block' );

        if ( ! $post ) {
            // Fallback
            $args  = array(
                'post_type'      => 'static_block',
                'post_status'    => 'publish',
                'name'           => $slug,
                'posts_per_page' => 1,
            );
            $query = new WP_Query( $args );
            $post  = $query->have_posts() ? $query->posts[0] : null;
            wp_reset_postdata();
        }

        if ( ! $post ) {
            return $echo ? '' : '';
        }

        // Force WPBakery to map all shortcodes before processing
        if ( class_exists( 'WPBMap' ) && method_exists( 'WPBMap', 'addAllMappedShortcodes' ) ) {
            WPBMap::addAllMappedShortcodes();
        }

        // Procesează shortcode-urile WPBakery și returnează HTML-ul
        $content = apply_filters( 'the_content', $post->post_content );
        $content = do_shortcode( $content );

        if ( $echo ) {
            echo $content;
        } else {
            return $content;
        }
    }
}

add_shortcode( 'rima_static_block', 'rima_static_block_shortcode_handler' );
add_shortcode( 'static_block_slug', 'rima_static_block_shortcode_handler' );
add_shortcode( 'static_block', 'rima_static_block_shortcode_handler' );
add_shortcode( 'html_block', 'rima_static_block_shortcode_handler' );

function rima_static_block_shortcode_handler( $atts ) {
    $atts = shortcode_atts( array(
        'slug' => '',
        'id'   => '',
    ), $atts );

    if ( ! empty( $atts['slug'] ) ) {
        return rima_static_block( $atts['slug'], false, 'slug' );
    } elseif ( ! empty( $atts['id'] ) ) {
        return rima_static_block( $atts['id'], false, 'id' );
    }

    return '';
}

// Ensure Custom HTML widgets process shortcodes
add_filter( 'widget_text', 'do_shortcode', 11 );
add_filter( 'widget_custom_html_content', 'do_shortcode', 11 );

// Test debug output
add_action( 'wp_footer', function() {
    echo "<!-- DEBUG SHORTCODE: " . do_shortcode('[static_block_slug slug="footer"]') . " -->";
} );

/* ============================================================
   1a. NAVIGATION ICONS FILTER (Inline SVG per endpoint)
   ============================================================ */
add_filter('rima_nav_icon', function($icon, $endpoint) {
    $icons = [
        'dashboard'    => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>',
        'my-courses'   => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>',
        'orders'       => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>',
        'edit-address' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
        'edit-account' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
    ];
    return isset($icons[$endpoint]) ? $icons[$endpoint] : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="4"/></svg>';
}, 10, 2);

/* ============================================================
   1b. LANGUAGE SYSTEM – Inline CSS + initial body class (no flash)
   ============================================================ */
add_action( 'wp_head', function() {
    // Determine active language: server pref (logged-in) > cookie (guest) > default EN
    $lang = 'en';
    if ( is_user_logged_in() ) {
        $lang = get_user_meta( get_current_user_id(), '_rima_lang_pref', true ) ?: 'en';
    } else {
        // Read googtrans cookie server-side if possible
        if ( ! empty( $_COOKIE['googtrans'] ) ) {
            $parts = explode( '/', trim( $_COOKIE['googtrans'], '/' ) );
            $cookie_lang = end( $parts );
            if ( in_array( $cookie_lang, [ 'en', 'ro' ], true ) ) {
                $lang = $cookie_lang;
            }
        }
    }
    // Store for JS below
    ?>
    <script>window.rimaInitLang = '<?php echo esc_js($lang); ?>';</script>
    <style id="rima-lang-style-inline">
    /* ── Manual bilingual spans ── */
    .rima-ro { display: none !important; }
    /* When body has rima-lang-ro: show RO spans, hide EN spans */
    body.rima-lang-ro .rima-ro { display: inline !important; }
    body.rima-lang-ro .rima-en { display: none !important; }

    /* ── Hide Google Translate toolbar ── */
    .goog-te-banner-frame.skiptranslate,
    .goog-te-gadget-icon,
    #\:1\.container { display: none !important; }
    body { top: 0px !important; }
    #goog-gt-tt,
    .goog-tooltip,
    .goog-tooltip:hover { display: none !important; }
    .goog-text-highlight {
        background-color: transparent !important;
        border: none !important;
        box-shadow: none !important;
    }
    </style>
    <?php
    // Apply class via inline script BEFORE body renders (avoids flash)
    if ( $lang === 'ro' ) {
        ?><script>document.documentElement.classList.add('rima-lang-ro');</script><?php
    }
}, 1 );

/* ============================================================
   1c. LANGUAGE SYSTEM – Footer: Google Translate + unified toggle
   ============================================================ */
add_action( 'wp_footer', function() {
    $lang_pref     = 'en';
    $is_logged_in  = is_user_logged_in();
    if ( $is_logged_in ) {
        $lang_pref = get_user_meta( get_current_user_id(), '_rima_lang_pref', true ) ?: 'en';
    }
    ?>
    <!-- Google Translate Widget (hidden) -->
    <div id="google_translate_element" style="display:none;"></div>
    <script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({
            pageLanguage: 'en',
            includedLanguages: 'ro,en',
            autoDisplay: false
        }, 'google_translate_element');
    }
    </script>
    <script async src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

    <script>
    /* ======================================================
       RIMA Unified Language Controller v2
       ====================================================== */
    (function() {
        'use strict';

        // ── State ──
        var RIMA_LANG = {
            current: window.rimaInitLang || 'en',
            isLoggedIn: <?php echo $is_logged_in ? 'true' : 'false'; ?>,
            ajaxUrl: '<?php echo admin_url('admin-ajax.php'); ?>',
            nonce: '<?php echo wp_create_nonce('rima_lang_nonce'); ?>',

            // ── Helpers ──
            setBodyClass: function(lang) {
                if (lang === 'ro') {
                    document.body.classList.add('rima-lang-ro');
                    document.body.classList.remove('rima-lang-en');
                } else {
                    document.body.classList.remove('rima-lang-ro');
                    document.body.classList.add('rima-lang-en');
                }
            },

            setCookie: function(lang) {
                var val = lang === 'ro' ? '/en/ro' : '/en/en';
                var domain = window.location.hostname;
                document.cookie = 'googtrans=' + val + '; path=/; domain=' + domain;
                document.cookie = 'googtrans=' + val + '; path=/';
            },

            triggerGoogleTranslate: function(lang) {
                var sel = document.querySelector('select.goog-te-combo');
                if (sel) {
                    sel.value = lang;
                    sel.dispatchEvent(new Event('change'));
                    return true;
                }
                return false;
            },

            saveToServer: function(lang, callback) {
                if (!this.isLoggedIn) { if(callback) callback(); return; }
                var xhr = new XMLHttpRequest();
                xhr.open('POST', this.ajaxUrl, true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && callback) callback();
                };
                xhr.send('action=rima_save_lang_pref&lang=' + lang + '&nonce=' + this.nonce);
            },

            // ── Main toggle ──
            toggle: function() {
                var newLang = (this.current === 'ro') ? 'en' : 'ro';
                this.apply(newLang, true);
            },

            apply: function(lang, saveServer) {
                this.current = lang;

                // 1. Body class (instant visual feedback for manual .rima-en/.rima-ro spans)
                this.setBodyClass(lang);

                // 2. localStorage (for JS components that read it)
                try { localStorage.setItem('rima_lang', lang); } catch(e) {}

                // 3. Cookie for Google Translate persistence
                this.setCookie(lang);

                // 4. Trigger Google Translate (no reload needed)
                var gtDone = this.triggerGoogleTranslate(lang);

                // 5. Update all toggle button labels on the page
                this.updateToggleUI(lang);

                // 6. Translate WooCommerce dynamic strings
                this.translateWcStrings(lang);

                // 7. Save to server for logged-in users
                if (saveServer) {
                    this.saveToServer(lang);
                }

                // 8. If GT not ready yet, retry after it loads
                if (!gtDone && lang === 'ro') {
                    var self = this;
                    var tries = 0;
                    var retry = setInterval(function() {
                        if (self.triggerGoogleTranslate(lang) || ++tries > 20) {
                            clearInterval(retry);
                        }
                    }, 300);
                }
            },

            updateToggleUI: function(lang) {
                // Update any toggle buttons with data-lang-en / data-lang-ro attributes
                var btns = document.querySelectorAll('[data-rima-lang-toggle]');
                btns.forEach(function(btn) {
                    var labelEl = btn.querySelector('.rima-lang-label');
                    if (labelEl) {
                        labelEl.textContent = lang === 'ro' ? 'EN' : 'RO';
                    }
                    btn.setAttribute('aria-label', lang === 'ro' ? 'Switch to English' : 'Comută în Română');
                    btn.title = lang === 'ro' ? 'Switch to English' : 'Comută în Română';
                });
            },

            translateWcStrings: function(lang) {
                var isRo = (lang === 'ro');
                // Mini-cart
                var emptyMsg = document.querySelector('.woocommerce-mini-cart__empty-message');
                if (emptyMsg) emptyMsg.textContent = isRo ? 'Niciun produs în coș.' : 'No products in the cart.';
                var viewCart = document.querySelector('.woocommerce-mini-cart__buttons .button.wc-forward:not(.checkout)');
                if (viewCart) viewCart.textContent = isRo ? 'Vezi Coșul' : 'View Cart';
                var checkoutBtn = document.querySelector('.woocommerce-mini-cart__buttons .button.checkout');
                if (checkoutBtn) checkoutBtn.textContent = isRo ? 'Finalizare Comandă' : 'Checkout';
            },

            // ── Init ──
            init: function() {
                var self = this;

                // Apply stored language on load
                this.setBodyClass(this.current);
                this.translateWcStrings(this.current);
                this.updateToggleUI(this.current);

                // Delegate click on ALL toggle selectors (unified)
                document.addEventListener('click', function(e) {
                    var t = e.target.closest(
                        '[data-rima-lang-toggle], #rima-lang-switch, #rima-header-lang-toggle, .rima-lang-toggle-card'
                    );
                    if (!t) return;
                    e.preventDefault();
                    e.stopPropagation();
                    self.toggle();
                });

                // Sync GT after it finishes loading (may take 1-2s)
                var syncTimer = setInterval(function() {
                    var sel = document.querySelector('select.goog-te-combo');
                    if (!sel) return;
                    clearInterval(syncTimer);
                    if (self.current === 'ro' && sel.value !== 'ro') {
                        sel.value = 'ro';
                        sel.dispatchEvent(new Event('change'));
                    } else if (self.current === 'en' && sel.value !== 'en') {
                        sel.value = 'en';
                        sel.dispatchEvent(new Event('change'));
                    }
                }, 400);

                // WooCommerce cart update → re-translate
                if (typeof jQuery !== 'undefined') {
                    jQuery(document.body).on(
                        'wc_fragments_refreshed wc_fragments_loaded updated_wc_div added_to_cart',
                        function() { self.translateWcStrings(self.current); }
                    );
                }

                // Expose globally
                window.RIMA_LANG = self;
                // Legacy compat: expose translateWooCommerceStrings
                window.translateWooCommerceStrings = function() { self.translateWcStrings(self.current); };
            }
        };

        // Auto-init when DOM is ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function() { RIMA_LANG.init(); });
        } else {
            RIMA_LANG.init();
        }
    })();
    </script>
    <?php
}, 5 );

/* ============================================================
   1d. AJAX: Save language preference (logged-in users only)
   ============================================================ */
add_action( 'wp_ajax_rima_save_lang_pref', function() {
    check_ajax_referer( 'rima_lang_nonce', 'nonce' );
    if ( ! is_user_logged_in() ) wp_send_json_error( 'not_logged_in' );
    $lang = sanitize_key( $_POST['lang'] ?? 'en' );
    if ( ! in_array( $lang, [ 'en', 'ro' ], true ) ) wp_send_json_error( 'invalid_lang' );
    update_user_meta( get_current_user_id(), '_rima_lang_pref', $lang );
    wp_send_json_success( [ 'lang' => $lang ] );
} );

/* ============================================================
   1d. AJAX: Contact Page Form Submission (guests + logged-in)
   ============================================================ */
add_action( 'wp_ajax_rima_contact_submit',        'rima_handle_contact_form' );
add_action( 'wp_ajax_nopriv_rima_contact_submit', 'rima_handle_contact_form' );

function rima_handle_contact_form() {
    // Nonce check
    if ( ! check_ajax_referer( 'rima_contact_nonce', 'rima_contact_nonce_field', false ) ) {
        wp_send_json_error( array( 'message' => 'Security check failed.' ) );
        return;
    }

    // Sanitize inputs
    $first_name = sanitize_text_field( $_POST['rc_first_name'] ?? '' );
    $last_name  = sanitize_text_field( $_POST['rc_last_name']  ?? '' );
    $email      = sanitize_email( $_POST['rc_email']           ?? '' );
    $subject    = sanitize_text_field( $_POST['rc_subject']    ?? '' );
    $topic      = sanitize_key( $_POST['rc_topic']             ?? 'other' );
    $message    = sanitize_textarea_field( $_POST['rc_message'] ?? '' );
    $gdpr       = ! empty( $_POST['rc_gdpr'] );

    // Validation
    if ( ! $first_name || ! $last_name ) {
        wp_send_json_error( array( 'message' => 'Name is required.' ) );
        return;
    }
    if ( ! is_email( $email ) ) {
        wp_send_json_error( array( 'message' => 'Invalid email address.' ) );
        return;
    }
    if ( ! $message ) {
        wp_send_json_error( array( 'message' => 'Message is required.' ) );
        return;
    }
    if ( ! $gdpr ) {
        wp_send_json_error( array( 'message' => 'GDPR consent is required.' ) );
        return;
    }

    $full_name    = trim( $first_name . ' ' . $last_name );
    $admin_email  = get_option( 'admin_email' );
    $site_name    = get_bloginfo( 'name' );

    // ── Email to admin ───────────────────────────────────────
    $mail_subject = sprintf( '[%s] Contact: %s — %s', $site_name, $full_name, $subject ?: $topic );
    $mail_body    = "New contact message from {$full_name} <{$email}>\n\n"
                  . "Topic:   {$topic}\n"
                  . "Subject: {$subject}\n\n"
                  . "Message:\n{$message}\n\n"
                  . '---\nSent from ' . get_site_url();

    $mail_headers = array(
        'Content-Type: text/plain; charset=UTF-8',
        "Reply-To: {$full_name} <{$email}>",
    );

    wp_mail( $admin_email, $mail_subject, $mail_body, $mail_headers );

    // ── Auto-reply to sender ─────────────────────────────────
    $reply_subject = sprintf( 'Am primit mesajul tău — %s', $site_name );
    $reply_body    = "Bună {$first_name},\n\n"
                   . "Mulțumim că ne-ai contactat! Am primit mesajul tău și îți vom răspunde în cel mult 24 de ore.\n\n"
                   . "Echipa Rima Academy\n"
                   . get_site_url();

    wp_mail( $email, $reply_subject, $reply_body, array( 'Content-Type: text/plain; charset=UTF-8' ) );

    // ── Save to DB as custom post ─────────────────────────────
    $post_id = wp_insert_post( array(
        'post_type'   => 'rima_contact_msg',
        'post_title'  => $mail_subject,
        'post_status' => 'private',
        'meta_input'  => array(
            '_rc_from_name'  => $full_name,
            '_rc_from_email' => $email,
            '_rc_topic'      => $topic,
            '_rc_subject'    => $subject,
            '_rc_message'    => $message,
            '_rc_gdpr'       => $gdpr ? '1' : '0',
            '_rc_ip'         => $_SERVER['REMOTE_ADDR'] ?? '',
            '_rc_date'       => current_time( 'mysql' ),
        ),
    ), false );

    wp_send_json_success( array( 'post_id' => $post_id ) );
}

// Register the private custom post type for storing contact messages
add_action( 'init', function() {
    register_post_type( 'rima_contact_msg', array(
        'label'         => 'Contact Messages',
        'public'        => false,
        'show_ui'       => true,
        'show_in_menu'  => true,
        'menu_icon'     => 'dashicons-email-alt',
        'supports'      => array( 'title', 'custom-fields' ),
        'capability_type' => 'post',
        'map_meta_cap'  => true,
    ) );
} );

/* ============================================================
   2. AVATAR UPLOAD â€” AJAX HANDLER
   ============================================================ */
function academist_child_upload_avatar() {
	check_ajax_referer( 'rima_nonce', 'nonce' );

	if ( ! is_user_logged_in() ) {
		wp_send_json_error( __( 'Not authenticated.', 'rima-academy' ) );
	}
	if ( empty( $_FILES['avatar'] ) ) {
		wp_send_json_error( __( 'No file received.', 'rima-academy' ) );
	}

	require_once ABSPATH . 'wp-admin/includes/image.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';

	$allowed  = array( 'jpg', 'jpeg', 'png', 'gif', 'webp' );
	$file_ext = strtolower( pathinfo( $_FILES['avatar']['name'], PATHINFO_EXTENSION ) );

	if ( ! in_array( $file_ext, $allowed ) ) {
		wp_send_json_error( __( 'Invalid file type. Accepted: JPG, PNG, GIF, WebP.', 'rima-academy' ) );
	}
	if ( $_FILES['avatar']['size'] > 2 * 1024 * 1024 ) {
		wp_send_json_error( __( 'File is too large. Max 2MB.', 'rima-academy' ) );
	}

	$attachment_id = media_handle_upload( 'avatar', 0 );
	if ( is_wp_error( $attachment_id ) ) {
		wp_send_json_error( $attachment_id->get_error_message() );
	}

	$url = wp_get_attachment_url( $attachment_id );
	update_user_meta( get_current_user_id(), 'social_profile_image', $url );

	wp_send_json_success( array( 'url' => $url ) );
}
add_action( 'wp_ajax_academist_child_upload_avatar', 'academist_child_upload_avatar' );

function academist_child_remove_avatar() {
	check_ajax_referer( 'rima_nonce', 'nonce' );
	if ( ! is_user_logged_in() ) {
		wp_send_json_error( __( 'Not authenticated.', 'rima-academy' ) );
	}
	delete_user_meta( get_current_user_id(), 'social_profile_image' );
	wp_send_json_success();
}
add_action( 'wp_ajax_academist_child_remove_avatar', 'academist_child_remove_avatar' );

/* ============================================================
   3. HEADER DROPDOWN â€” Override membership nav items
   ============================================================ */
function academist_child_override_header_nav_items( $items, $dashboard_url = '' ) {
	if ( ! class_exists( 'WooCommerce' ) ) return $items;
	return array(
		array( 'url' => wc_get_page_permalink('myaccount'),             'text' => __('Dashboard',        'rima-academy') ),
		array( 'url' => wc_get_account_endpoint_url('my-courses'),      'text' => __('My Courses',       'rima-academy') ),
		array( 'url' => wc_get_account_endpoint_url('orders'),          'text' => __('My Orders',        'rima-academy') ),
		array( 'url' => wc_get_account_endpoint_url('edit-account'),    'text' => __('Account Details',  'rima-academy') ),
	);
}
add_filter( 'academist_membership_dashboard_navigation_pages', 'academist_child_override_header_nav_items', 99, 2 );

/* ============================================================
   4. REMOVE OLD PARENT THEME WOOCOMMERCE MENU OVERRIDES
   ============================================================ */
function academist_child_remove_parent_woo_menu() {
	remove_filter( 'woocommerce_account_menu_items', 'academist_membership_extend_woo_navigation' );
	remove_filter( 'academist_membership_dashboard_navigation_pages', 'academist_lms_add_profile_navigation_item', 10 );
}
add_action( 'init', 'academist_child_remove_parent_woo_menu', 25 );

/* ============================================================
   5. PLUGIN TEMPLATE OVERRIDE PATH
   ============================================================ */
// Allow the membership plugin's template to be overridden in child theme
add_filter( 'academist_membership_filter_templates_dir', function( $dir ) {
	$child_dir = get_stylesheet_directory() . '/academist-membership/';
	return file_exists( $child_dir ) ? $child_dir : $dir;
});add_action('wp_head', function() {
    if ( class_exists('WooCommerce') && is_user_logged_in() ) {
        echo '<script type="text/javascript">
        var rima_ajax_obj = {
            "ajax_url": "' . esc_url(admin_url('admin-ajax.php')) . '",
            "nonce": "' . wp_create_nonce('rima_nonce') . '"
        };
        </script>';
    }
});
add_action('wp_footer', function() {
    if ( class_exists('WooCommerce') && is_user_logged_in() ) {
        ?>
        <script>
        jQuery(document).ready(function($) {
            // Bind to both avatar upload inputs (sidebar and edit account form)
            $('#rima-avatar-upload, #avatar-upload-input').on('change', function() {
                var file = this.files[0];
                if (!file) return;

                var formData = new FormData();
                formData.append('avatar', file);
                formData.append('action', 'academist_child_upload_avatar');
                formData.append('nonce', rima_ajax_obj.nonce);

                var statusDiv = $('#avatar-upload-status');
                if(statusDiv.length) {
                    statusDiv.show().text('Uploading...').removeClass('text-danger text-success').addClass('text-info');
                }

                $.ajax({
                    url: rima_ajax_obj.ajax_url,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if(response.success) {
                            $('#edit-avatar-preview').css('background-image', 'url(' + response.data.url + ')');
                            $('#user-avatar-display').css('background-image', 'url(' + response.data.url + ')');
                            if(statusDiv.length) {
                                statusDiv.text('Avatar updated!').removeClass('text-info text-danger').addClass('text-success');
                                setTimeout(() => statusDiv.fadeOut(), 3000);
                            }
                        } else {
                            if(statusDiv.length) {
                                statusDiv.text('Error: ' + response.data).removeClass('text-info').addClass('text-danger');
                            } else {
                                alert('Error uploading avatar: ' + response.data);
                            }
                        }
                    },
                    error: function() {
                        if(statusDiv.length) {
                            statusDiv.text('Network error.').removeClass('text-info').addClass('text-danger');
                        } else {
                            alert('Network error while uploading avatar.');
                        }
                    }
                });
            });
        });
        </script>
        <?php
    }
}, 100);

/* ============================================================
   6. OVERRIDE MY COURSES ENDPOINT TEMPLATE (Removed to use modern 2026 UI)
   ============================================================ */
// Removed legacy academist_child_my_courses_content to prevent duplicated view

/* ============================================================
   7. FORCE ENABLE REGISTRATION (Bypass WP Option Check)
   ============================================================ */
add_filter( 'pre_option_users_can_register', '__return_true' );
add_filter( 'option_users_can_register', '__return_true' );
add_filter( 'pre_option_woocommerce_enable_myaccount_registration', function() { return 'yes'; } );
add_filter( 'option_woocommerce_enable_myaccount_registration', function() { return 'yes'; } );

/* ============================================================
   7.1 FORCE CHILD THEME TEMPLATE FOR WOOCOMMERCE LOGIN (ULTIMATE)
   ============================================================ */
add_action('init', function() {
    remove_shortcode('woocommerce_my_account');
    add_shortcode('woocommerce_my_account', 'rima_force_my_account_shortcode');
});

function rima_force_my_account_shortcode($atts) {
    ob_start();
    
    global $wp;
    
    if ( is_user_logged_in() ) {
        // Let WooCommerce handle the logged-in view
        if ( function_exists('wc_get_template') ) {
            wc_get_template( 'myaccount/my-account.php', array(
                'current_user' => get_user_by( 'id', get_current_user_id() ),
            ) );
        }
    } elseif ( isset( $wp->query_vars['lost-password'] ) ) {
        // We are on the Lost Password page! Load the lost password template.
        if ( function_exists('wc_get_template') ) {
            wc_get_template( 'myaccount/form-lost-password.php', array(
                'form' => 'lost_password',
            ) );
        }
    } else {
        // FORCE our custom login template!
        $custom_template = get_stylesheet_directory() . '/woocommerce/myaccount/form-login.php';
        if ( file_exists( $custom_template ) ) {
            include $custom_template;
        } else {
            echo '<div class="woocommerce-error">ERROR: Custom RIMA template file is missing at <code>' . esc_html($custom_template) . '</code>. Please make sure the <strong>woocommerce</strong> folder was uploaded inside the academist-child theme.</div>';
            // Fallback to default
            if ( function_exists('wc_get_template') ) {
                wc_get_template( 'myaccount/form-login.php' );
            }
        }
    }
    
    return ob_get_clean();
}

/* ============================================================
   8. BULLETPROOF REGISTRATION & LOGIN SHORTCODE OVERRIDES
   ============================================================ */
add_action('wp_loaded', function() {
    remove_shortcode('eltdf_user_register');
    add_shortcode('eltdf_user_register', 'rima_custom_user_register_html');
});

function rima_custom_user_register_html() {
    ob_start();
    ?>
    <div class="eltdf-social-register-holder">
        <form method="post" class="eltdf-register-form">
            <fieldset>
                <div>
                    <label>Username*</label>
                    <input type="text" name="user_register_name" id="user_register_name" value="" required pattern=".{3,}" title="Three or more characters"/>
                </div>
                <div>
                    <label>Email*</label>
                    <input type="email" name="user_register_email" id="user_register_email" value="" required />
                </div>
                <div>
                    <label>Password*</label>
                    <input type="password" name="user_register_password" id="user_register_password" value="" required />
                </div>
                <div>
                    <label>Repeat Password*</label>
                    <input type="password" name="user_register_confirm_password" id="user_register_confirm_password"  value="" required />
                </div>
                
                <div class="eltdf-register-button-holder" style="margin-top: 20px;">
                    <button type="submit" class="eltdf-btn eltdf-btn-solid eltdf-btn-small" style="background-color: #991b1b !important; border-color: #991b1b !important;"><i class="fa fa-user-plus me-2" style="margin-right: 5px;"></i> Register</button>
                    <?php wp_nonce_field( 'eltdf-ajax-register-nonce', 'eltdf-register-security' ); ?>
                </div>
            </fieldset>
        </form>
        <div class="eltdf-membership-response-holder clearfix"></div>
    </div>
    <?php
    return ob_get_clean();
}

/* ============================================================
   8.5 AJAX UPDATE CART QUANTITY
   ============================================================ */
add_action('wp_ajax_rima_update_cart_quantity', 'rima_update_cart_quantity');
add_action('wp_ajax_nopriv_rima_update_cart_quantity', 'rima_update_cart_quantity');
function rima_update_cart_quantity() {
    if ( ! isset( $_POST['cart_item_key'] ) || ! isset( $_POST['qty'] ) ) {
        wp_send_json_error();
    }
    $cart_item_key = sanitize_text_field( $_POST['cart_item_key'] );
    $qty = intval( $_POST['qty'] );
    
    if ( $qty <= 0 ) {
        WC()->cart->remove_cart_item( $cart_item_key );
    } else {
        WC()->cart->set_quantity( $cart_item_key, $qty );
    }
    
    WC_AJAX::get_refreshed_fragments();
    wp_die();
}

/* ============================================================
   9. LMS AUTHENTICATION REDIRECTS & FLOATING SIDE-CART
   ============================================================ */
add_action('wp_footer', function() {
    $my_account_url = class_exists('WooCommerce') ? wc_get_page_permalink('myaccount') : '/my-account/';
    
    // Build user data for the menu
    if ( is_user_logged_in() ) {
        $current_user  = wp_get_current_user();
        $display_name  = $current_user->display_name ?: $current_user->user_login;
        $first_name    = $current_user->first_name ?: '';
        $last_name     = $current_user->last_name ?: '';
        // Initials: first letter of first and last name, fallback to first two of display_name
        $initials = '';
        if ($first_name && $last_name) {
            $initials = strtoupper(mb_substr($first_name,0,1) . mb_substr($last_name,0,1));
        } elseif ($display_name) {
            $parts = explode(' ', trim($display_name));
            $initials = strtoupper(mb_substr($parts[0],0,1) . (isset($parts[1]) ? mb_substr($parts[1],0,1) : ''));
        }
        if (empty($initials)) $initials = 'U';
        
        // Avatar URL
        $avatar_url = get_avatar_url($current_user->ID, ['size' => 80]);
        $has_custom_avatar = !strpos($avatar_url, 'gravatar.com/avatar/') || strpos($avatar_url, 'd=mm') === false;
        
        // Dashboard / My Account links
        $dashboard_url  = $my_account_url;
        $courses_url    = $my_account_url . 'my-courses/';
        $orders_url     = $my_account_url . 'orders/';
        $profile_url    = $my_account_url . 'edit-account/';
        $logout_url     = wp_logout_url( home_url() );
        
        $is_logged_in_html = 'true';
    } else {
        $display_name = '';
        $initials = '';
        $avatar_url = '';
        $has_custom_avatar = false;
        $dashboard_url = $courses_url = $orders_url = $profile_url = $logout_url = '';
        $is_logged_in_html = 'false';
    }
    ?>
    
    <!-- RIMA Premium User Menu CSS -->
    <style>
    /* Hide original theme login widget */
    .eltdf-login-register-widget { display: none !important; }

    /* Disable Top Bar completely */
    .eltdf-top-bar, 
    .eltdf-top-bar-background, 
    .eltdf-top-bar-wrapper,
    #eltdf-top-bar,
    .top-bar,
    .eltdf-top-bar-area { 
        display: none !important; 
        height: 0 !important; 
        overflow: hidden !important; 
        visibility: hidden !important; 
    }

    /* Hide the red square side menu opener */
    .eltdf-side-menu-button-opener {
        display: none !important;
    }

    /* Disable default Academist hover cart dropdown */
    .eltdf-shopping-cart-dropdown,
    .eltdf-shopping-cart-dropdown-inner {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
    }
    
    /* Premium User Menu Container - inline with header cart */
    #rima-user-menu-container {
        display: inline-flex;
        vertical-align: middle;
        align-items: center;
        gap: 10px;
        margin-right: 12px;
    }


    /* Not logged in: Login/Register buttons */
    .rima-topbar-btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 7px 16px;
        border-radius: 30px;
        font-size: 12.5px;
        font-weight: 600;
        letter-spacing: .2px;
        text-decoration: none !important;
        transition: all 0.2s ease;
        cursor: pointer;
        line-height: 1;
        white-space: nowrap;
    }
    .rima-topbar-btn-login {
        background: transparent;
        color: #374151 !important;
        border: 1.5px solid rgba(55,65,81,0.25) !important;
    }
    .rima-topbar-btn-login:hover {
        background: rgba(11,29,58,0.05);
        border-color: #374151 !important;
        color: #0B1D3A !important;
    }
    .rima-topbar-btn-register {
        background: linear-gradient(135deg, #FF1949 0%, #c8002f 100%);
        color: #fff !important;
        border: none !important;
        box-shadow: 0 3px 10px rgba(255,25,73,0.25);
    }
    .rima-topbar-btn-register:hover {
        background: linear-gradient(135deg, #e6003d 0%, #a8002a 100%);
        transform: translateY(-1px);
        box-shadow: 0 5px 16px rgba(255,25,73,0.35);
        color: #fff !important;
    }
    
    /* Logged in: Avatar + dropdown */
    .rima-user-avatar-wrap {
        position: relative;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 5px;
        height: 100%;
    }
    .rima-user-avatar {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        border: 2px solid #e5e7eb;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #0B1D3A, #17325c);
        color: #fff;
        font-size: 13px;
        font-weight: 700;
        font-family: 'Inter', sans-serif;
        box-shadow: 0 2px 8px rgba(0,0,0,0.12);
        transition: all 0.2s ease;
        user-select: none;
    }
    .rima-user-avatar img {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 50%;
    }
    .rima-user-avatar-wrap:hover .rima-user-avatar {
        box-shadow: 0 4px 16px rgba(0,0,0,0.2);
        transform: scale(1.05);
    }
    
    /* Dropdown */
    .rima-user-dropdown {
        position: absolute;
        top: calc(100% + 12px);
        right: 0;
        min-width: 240px;
        background: #fff;
        border-radius: 16px;
        box-shadow: 0 12px 48px rgba(0,0,0,0.14);
        padding: 8px 0;
        z-index: 999999;
        opacity: 0;
        visibility: hidden;
        transform: translateY(-8px) scale(0.97);
        transition: all 0.22s cubic-bezier(0.34,1.56,0.64,1);
        pointer-events: none;
    }
    .rima-user-dropdown.rima-open {
        opacity: 1;
        visibility: visible;
        transform: translateY(0) scale(1);
        pointer-events: all;
    }
    
    /* Dropdown header with user info */
    .rima-dropdown-header {
        padding: 14px 18px 10px;
        border-bottom: 1px solid #f1f1f1;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .rima-dropdown-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: linear-gradient(135deg, #0B1D3A, #17325c);
        color: #fff;
        font-weight: 700;
        font-size: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        flex-shrink: 0;
    }
    .rima-dropdown-avatar img {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 50%;
    }
    .rima-dropdown-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .rima-dropdown-name {
        font-size: 13px;
        font-weight: 700;
        color: #0B1D3A;
        line-height: 1.2;
    }
    .rima-dropdown-role {
        font-size: 10px;
        color: #008b9e;
        background: rgba(0, 229, 255, 0.1);
        border: 1px solid rgba(0, 229, 255, 0.2);
        padding: 3px 8px;
        border-radius: 12px;
        margin-top: 5px;
        display: inline-block;
        font-weight: 700;
        letter-spacing: 0.5px;
    }
    
    /* Dropdown box-sizing override to prevent layout overflow */
    .rima-user-dropdown,
    .rima-user-dropdown * {
        box-sizing: border-box !important;
    }

    /* Dropdown items */
    .rima-dropdown-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 18px;
        font-size: 13px;
        color: #374151 !important;
        text-decoration: none !important;
        transition: all 0.15s ease;
        border: none;
        background: transparent;
        width: 100%;
        text-align: left;
        cursor: pointer;
    }
    .rima-dropdown-item:hover {
        background: rgba(255, 71, 87, 0.08) !important;
        color: #ff4757 !important;
        padding-left: 22px;
    }
    .rima-dropdown-item .rima-di-icon {
        width: 28px;
        height: 28px;
        border-radius: 8px;
        background: #f3f4f6;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        flex-shrink: 0;
        transition: all 0.15s;
    }
    .rima-dropdown-item:hover .rima-di-icon {
        background: rgba(255, 71, 87, 0.15) !important;
        color: #ff4757 !important;
    }
    .rima-dropdown-divider {
        height: 1px;
        background: #f1f1f1;
        margin: 6px 0;
    }
    .rima-dropdown-item.rima-logout {
        color: #dc2626 !important;
    }
    .rima-dropdown-item.rima-logout:hover {
        background: #fff5f5;
    }
    .rima-dropdown-item.rima-logout .rima-di-icon {
        background: #fee2e2;
    }
    
    /* Arrow indicator on avatar */
    .rima-user-caret {
        font-size: 10px;
        color: #9ca3af;
        transition: transform 0.2s;
        margin-left: 3px;
    }
    .rima-user-avatar-wrap.rima-open .rima-user-caret {
        transform: rotate(180deg);
        color: #0B1D3A;
    }
    /* RIMA Mobile Bottom Nav */
    #rima-mobile-bottom-nav {
        display: none;
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        background-color: #ffffff !important;
        box-shadow: 0 -4px 15px rgba(0,0,0,0.05);
        z-index: 99999;
        justify-content: space-around;
        padding: 12px 0 8px 0;
        border-top: 1px solid #f0f0f0;
    }
    .rima-mob-nav-item {
        display: flex;
        flex-direction: column;
        align-items: center;
        color: #555;
        text-decoration: none;
        font-size: 11px;
        font-weight: 600;
        font-family: 'Inter', sans-serif;
        transition: color 0.3s ease;
    }
    .rima-mob-nav-item:hover, .rima-mob-nav-item:active {
        color: #ff0050; /* Brand pink */
    }
    .rima-mob-icon {
        margin-bottom: 4px;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .rima-mob-icon svg {
        width: 22px;
        height: 22px;
        stroke: currentColor;
    }
    .rima-mob-cart-badge {
        position: absolute;
        top: -6px;
        right: -10px;
        background: #ff0050;
        color: white;
        font-size: 10px;
        font-weight: bold;
        min-width: 16px;
        height: 16px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        line-height: 1;
    }

    @media only screen and (max-width: 1024px) {
        #rima-mobile-bottom-nav {
            display: flex !important;
        }
        body {
            padding-bottom: 100px !important; 
        }
        
        /* Ensure top cart and user menu are visible when injected in mobile header */
        .eltdf-mobile-header .eltdf-shopping-cart-holder,
        .eltdf-mobile-header .eltdf-header-cart {
            display: inline-block !important;
            margin-right: 15px;
            vertical-align: middle;
        }
        .eltdf-mobile-header #rima-user-menu-container {
            display: inline-block !important;
            margin-right: 15px;
            vertical-align: middle;
        }
        .eltdf-mobile-header .eltdf-position-right {
            display: flex !important;
            align-items: center !important;
            justify-content: flex-end !important;
            padding-right: 20px;
        }
    }
    </style>
    
    <!-- RIMA Premium User Menu HTML -->
    <div id="rima-user-menu-container">
        <?php if ( is_user_logged_in() ) : 
            // Fetch custom avatar or fallback
            $profile_image = get_user_meta( $current_user->ID, 'social_profile_image', true );
            if ( empty( $profile_image ) ) {
                $profile_image = get_avatar_url( $current_user->ID, array( 'size' => 80 ) );
            }
        ?>
        <!-- LOGGED IN: Avatar + Dropdown -->
        <div class="rima-user-avatar-wrap" id="rimaUserAvatarWrap">
            <div class="rima-user-avatar" id="rimaUserAvatar">
                <img src="<?php echo esc_url($profile_image); ?>" alt="Avatar">
            </div>
            <span class="rima-user-caret">▾</span>
            
            <!-- Dropdown -->
            <div class="rima-user-dropdown" id="rimaUserDropdown">
                <!-- Header -->
                <div class="rima-dropdown-header">
                    <div class="rima-dropdown-avatar">
                        <img src="<?php echo esc_url($profile_image); ?>" alt="Avatar">
                    </div>
                    <div>
                        <div class="rima-dropdown-name"><?php echo esc_html($display_name); ?></div>
                        <?php 
                            $user_roles = (array) $current_user->roles;
                            $role_slug  = !empty($user_roles) ? $user_roles[0] : '';
                            global $wp_roles;
                            $role_name  = isset($wp_roles->roles[$role_slug]['name']) ? translate_user_role($wp_roles->roles[$role_slug]['name']) : 'Student';
                        ?>
                        <div class="rima-dropdown-role"><?php echo esc_html($role_name); ?></div>
                    </div>
                </div>
                
                <!-- Menu Items -->
                <a href="<?php echo esc_url($dashboard_url); ?>" class="rima-dropdown-item">
                    <span class="rima-di-icon">📊</span>
                    <span class="rima-en">Dashboard</span>
                    <span class="rima-ro">Panou de Control</span>
                </a>
                <a href="<?php echo esc_url($courses_url); ?>" class="rima-dropdown-item">
                    <span class="rima-di-icon">📚</span>
                    <span class="rima-en">My Courses</span>
                    <span class="rima-ro">Cursurile Mele</span>
                </a>
                <a href="<?php echo esc_url($orders_url); ?>" class="rima-dropdown-item">
                    <span class="rima-di-icon">🛍️</span>
                    <span class="rima-en">Orders</span>
                    <span class="rima-ro">Comenzi</span>
                </a>
                <a href="<?php echo esc_url($profile_url); ?>" class="rima-dropdown-item">
                    <span class="rima-di-icon">⚙️</span>
                    <span class="rima-en">Account Details</span>
                    <span class="rima-ro">Detalii Cont</span>
                </a>
                
                <div class="rima-dropdown-divider"></div>
                
                <a href="<?php echo esc_url($logout_url); ?>" class="rima-dropdown-item rima-logout">
                    <span class="rima-di-icon">🚪</span>
                    <span class="rima-en">Logout</span>
                    <span class="rima-ro">Deconectare</span>
                </a>
            </div>
        </div>
        
        <?php else : ?>
        <!-- NOT LOGGED IN: Login + Register buttons -->
        <a href="<?php echo esc_url($my_account_url); ?>" class="rima-topbar-btn rima-topbar-btn-login">
            👤 <span class="rima-en">Login</span><span class="rima-ro">Conectare</span>
        </a>
        <a href="<?php echo esc_url($my_account_url . '#rima-register-tab'); ?>" class="rima-topbar-btn rima-topbar-btn-register">
            ✨ <span class="rima-en">Register</span><span class="rima-ro">Înregistrare</span>
        </a>
        <?php endif; ?>
    </div>


    <script>
    jQuery(document).ready(function($) {

        // ─── 1. Relocate user menu next to Cart in header ───
        function relocateHeaderWidgets() {
            var cartOuter = document.querySelector('.eltdf-shopping-cart-holder');
            var ourMenu   = document.getElementById('rima-user-menu-container');

            if (window.innerWidth <= 1024) {
                // Move to mobile header if mobile header exists
                var mobileHeaderRight = document.querySelector('.eltdf-mobile-header .eltdf-position-right-inner') || document.querySelector('.eltdf-mobile-header .eltdf-mobile-menu-opener');
                
                if (mobileHeaderRight && ourMenu) {
                    if (mobileHeaderRight.parentNode && !mobileHeaderRight.parentNode.contains(ourMenu)) {
                        mobileHeaderRight.parentNode.insertBefore(ourMenu, mobileHeaderRight);
                    }
                    if (cartOuter && mobileHeaderRight.parentNode && !mobileHeaderRight.parentNode.contains(cartOuter)) {
                        mobileHeaderRight.parentNode.insertBefore(cartOuter, mobileHeaderRight);
                    }
                }
            } else {
                if (cartOuter && ourMenu && !cartOuter.parentNode.contains(ourMenu)) {
                    cartOuter.parentNode.insertBefore(ourMenu, cartOuter);
                }
            }
        }
        relocateHeaderWidgets();
        // Re-run on scroll and resize
        $(window).on('scroll.rimaHeader resize.rimaHeader', function() { relocateHeaderWidgets(); });

        // ─── 2. Avatar dropdown toggle ───
        $(document).on('click', '#rimaUserAvatarWrap', function(e) {
            e.stopPropagation();
            $(this).toggleClass('rima-open');
            $('#rimaUserDropdown').toggleClass('rima-open');
        });
        $(document).on('click', function(e) {
            if (!$(e.target).closest('#rimaUserAvatarWrap').length) {
                $('#rimaUserAvatarWrap').removeClass('rima-open');
                $('#rimaUserDropdown').removeClass('rima-open');
            }
        });

        // ─── 3. Redirect leftover theme auth openers ───
        var authLinks = document.querySelectorAll('.eltdf-login-opener, .eltdf-register-opener');
        authLinks.forEach(function(link) {
            link.classList.remove('eltdf-modal-opener');
            link.setAttribute('data-modal', '');
            link.href = '<?php echo esc_url($my_account_url); ?>';
        });

        // ─── 4. Slide-out Side Cart (robust binding) ───
        // Use true capture phase listener to completely bypass any theme scripts calling stopPropagation
        document.addEventListener('click', function(e) {
            var cartTarget = e.target.closest('.eltdf-shopping-cart-holder, .eltdf-header-cart, .eltdf-cart-icon');
            if (cartTarget) {
                e.preventDefault();
                e.stopPropagation();
                var sideCart = document.getElementById('rima-side-cart');
                var overlay = document.getElementById('rima-side-cart-overlay');
                if (sideCart) sideCart.classList.add('rima-cart-open');
                if (overlay) overlay.classList.add('rima-cart-open');
            }
        }, true);
        
        // Keep checking and overriding the href just in case
        setInterval(function() {
            $('.eltdf-shopping-cart-holder a, .eltdf-header-cart > a').attr('href', 'javascript:void(0);');
        }, 1500);

        $(document).on('click', '#rima-side-cart-close, #rima-side-cart-overlay', function() {
            $('#rima-side-cart').removeClass('rima-cart-open');
            $('#rima-side-cart-overlay').removeClass('rima-cart-open');
        });

        // ─── Mobile Bottom Nav Actions ───
        $(document).on('click', '#rima-mob-nav-cart', function(e) {
            e.preventDefault();
            $('#rima-side-cart').addClass('rima-cart-open');
            $('#rima-side-cart-overlay').addClass('rima-cart-open');
        });

        $(document).on('click', '#rima-mobile-menu-toggle', function(e) {
            e.preventDefault();
            // Trigger theme's mobile menu opener
            $('.eltdf-mobile-menu-opener a').trigger('click');
        });

        // ─── 5 & 7. Language + WC strings handled by RIMA_LANG controller (see wp_footer) ───
        // window.RIMA_LANG.current === 'ro' | 'en'
        // window.translateWooCommerceStrings() is exposed by RIMA_LANG for legacy calls

    }); // end ready

    // Listen to WooCommerce added_to_cart event via jQuery
    jQuery(document).ready(function($) {
        $(document).on('added_to_cart', function(event, fragments, cart_hash, $button) {
            // Get product name dynamically (from button data, or fallback to single page title)
            var productName = 'Course';
            if ($button && ($button.attr('data-product_name') || $button.data('product_name'))) {
                productName = $button.attr('data-product_name') || $button.data('product_name');
            } else if ($('.rsc-hero-title').length) {
                productName = $('.rsc-hero-title').text().trim();
            } else if ($('h1.product_title').length) {
                productName = $('h1.product_title').text().trim();
            }

            var isRo = (window.RIMA_LANG ? window.RIMA_LANG.current === 'ro' : false) || (localStorage.getItem('rima_lang') === 'ro');
            var msg = isRo ? '"' + productName + '" a fost adăugat în coș!' : '"' + productName + '" has been added to cart!';
            
            // Show success toast with dynamic message
            var $toast = $('#rima-cart-toast');
            if($toast.length) {
                $toast.text(msg).addClass('show-toast');
                setTimeout(function() {
                    $toast.removeClass('show-toast');
                }, 4000);
            }
    
            // Update Side Cart HTML with fragments
            if(fragments && fragments['div.widget_shopping_cart_content']) {
                $('#rima-side-cart-content').html(fragments['div.widget_shopping_cart_content']);
                if (typeof window.translateWooCommerceStrings === 'function') {
                    window.translateWooCommerceStrings();
                }
            }
        });

        // AJAX update cart quantity on +/- button clicks
        $(document).on('click', '.rima-cart-qty-minus, .rima-cart-qty-plus', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var $btn = $(this);
            var key = $btn.attr('data-cart_item_key');
            var $input = $btn.siblings('.rima-cart-qty-input');
            var currentQty = parseInt($input.val()) || 1;
            var newQty = $btn.hasClass('rima-cart-qty-plus') ? currentQty + 1 : currentQty - 1;
            
            if (newQty < 0) newQty = 0;
            
            $('#rima-side-cart').addClass('rima-cart-loading');
            
            $.ajax({
                type: 'POST',
                url: '/wp-admin/admin-ajax.php',
                data: {
                    action: 'rima_update_cart_quantity',
                    cart_item_key: key,
                    qty: newQty
                },
                success: function(response) {
                    if (response && response.fragments) {
                        var fragments = response.fragments;
                        $.each(fragments, function(key, value) {
                            $(key).replaceWith(value);
                        });
                        $(document.body).trigger('wc_fragments_refreshed');
                    }
                    $('#rima-side-cart').removeClass('rima-cart-loading');
                },
                error: function() {
                    $('#rima-side-cart').removeClass('rima-cart-loading');
                }
            });
        });

        // Auto-open side-cart on page load if WooCommerce notices (added to cart messages) are present
        if ($('.woocommerce-message').length > 0) {
            var sideCart = document.getElementById('rima-side-cart');
            var cartOverlay = document.getElementById('rima-side-cart-overlay');
            if(sideCart) {
                sideCart.classList.add('rima-cart-open');
                cartOverlay.classList.add('rima-cart-open');
            }
        }
    });
    </script>

    <!-- Toast Notification -->
    <div id="rima-cart-toast" class="rima-cart-toast"></div>

    <!-- Side Cart HTML -->
    <div id="rima-side-cart-overlay" class="rima-side-cart-overlay"></div>
    <div id="rima-side-cart" class="rima-side-cart">
        <div class="rima-side-cart-header">
            <h4><span class="rima-en">Your Cart</span><span class="rima-ro">Coșul Tău</span></h4>
            <span id="rima-side-cart-close" class="rima-side-cart-close">&times;</span>
        </div>
        <div id="rima-side-cart-content" class="rima-side-cart-content widget_shopping_cart_content">
            <?php 
            if(class_exists('WooCommerce')) {
                woocommerce_mini_cart(); 
            }
            ?>
        </div>
    </div>

    <!-- Mobile Bottom Navigation -->
    <div id="rima-mobile-bottom-nav">
        <a href="https://rima-academy.com/" class="rima-mob-nav-item">
            <span class="rima-mob-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
            </span>
            <span class="rima-en">Home</span><span class="rima-ro">Acasă</span>
        </a>
        <a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" class="rima-mob-nav-item">
            <span class="rima-mob-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
            </span>
            <span class="rima-en">Account</span><span class="rima-ro">Contul meu</span>
        </a>
        <a href="#" class="rima-mob-nav-item" id="rima-mobile-menu-toggle">
            <span class="rima-mob-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
            </span>
            <span class="rima-en">Menu</span><span class="rima-ro">Meniu</span>
        </a>
        <a href="#" class="rima-mob-nav-item" id="rima-mob-nav-cart">
            <span class="rima-mob-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
                <span class="rima-mob-cart-badge">0</span>
            </span>
            <span class="rima-en">Cart</span><span class="rima-ro">Coșul meu</span>
        </a>
    </div>

    <script>
    jQuery(document).ready(function($) {
        // Mobile bottom nav cart trigger
        $(document).on('click', '#rima-mob-nav-cart', function(e) {
            e.preventDefault();
            $('#rima-side-cart').addClass('rima-cart-open');
            $('#rima-side-cart-overlay').addClass('rima-cart-open');
        });

        // Sync mobile cart badge with desktop cart badge every second
        setInterval(function() {
            var count = $('.eltdf-cart-number').first().text();
            if (count !== undefined && count !== '') {
                $('.rima-mob-cart-badge').text(count);
            }
        }, 1000);
    });
    </script>

    <?php
}, 999);

/* ============================================================
   10. REGISTRATION VALIDATION (MATH CAPTCHA & CONFIRM PASSWORD)
   ============================================================ */
add_action( 'woocommerce_register_post', 'rima_validate_custom_register_fields', 10, 3 );
function rima_validate_custom_register_fields( $username, $email, $validation_errors ) {
    
    // 1. Validate Confirm Password
    if ( isset( $_POST['password'] ) && isset( $_POST['rima_confirm_password'] ) ) {
        if ( $_POST['password'] !== $_POST['rima_confirm_password'] ) {
            $validation_errors->add( 'password_mismatch', __( 'The passwords do not match.', 'woocommerce' ) );
        }
    }
    
    // 2. Validate Math Captcha
    if ( isset( $_POST['rima_math_answer'] ) && isset( $_POST['rima_math_hash'] ) ) {
        $answer = sanitize_text_field( $_POST['rima_math_answer'] );
        $hash   = sanitize_text_field( $_POST['rima_math_hash'] );
        
        $expected_hash = md5('rima_math_' . $answer);
        
        if ( $hash !== $expected_hash ) {
            $validation_errors->add( 'math_captcha_error', __( 'The anti-spam math answer is incorrect.', 'woocommerce' ) );
        }
    } else {
        $validation_errors->add( 'math_captcha_missing', __( 'Please solve the anti-spam math question.', 'woocommerce' ) );
    }
}

add_filter( 'woocommerce_process_login_errors', 'rima_validate_custom_login_fields', 10, 3 );
function rima_validate_custom_login_fields( $validation_errors, $login, $password ) {
    
    // Validate Math Captcha for Login
    if ( isset( $_POST['rima_math_answer_login'] ) && isset( $_POST['rima_math_hash_login'] ) ) {
        $answer = sanitize_text_field( $_POST['rima_math_answer_login'] );
        $hash   = sanitize_text_field( $_POST['rima_math_hash_login'] );
        
        $expected_hash = md5('rima_math_' . $answer);
        
        if ( $hash !== $expected_hash ) {
            $validation_errors->add( 'math_captcha_error', __( 'The anti-spam math answer is incorrect.', 'woocommerce' ) );
        }
    } else {
        // Only trigger this if we are actually submitting the login form, since WooCommerce might process logins from other places.
        // We check if the custom nonce is present or just rely on the form submission via our form
        if ( isset($_POST['login']) ) {
            $validation_errors->add( 'math_captcha_missing', __( 'Please solve the anti-spam math question.', 'woocommerce' ) );
        }
    }
    return $validation_errors;
}

/* ============================================================
   11. EMAIL VERIFICATION ON REGISTRATION
   ============================================================ */
// 1. Prevent auto-login and set user as unverified
add_filter( 'woocommerce_registration_auth_new_customer', '__return_false' );

add_action( 'woocommerce_created_customer', 'rima_require_email_verification_on_register', 10, 3 );
function rima_require_email_verification_on_register( $customer_id, $new_customer_data, $password_generated ) {
    $activation_hash = wp_generate_password( 20, false );
    update_user_meta( $customer_id, 'rima_is_activated', '0' );
    update_user_meta( $customer_id, 'rima_activation_hash', $activation_hash );
    
    // Send Email
    $user = get_user_by( 'id', $customer_id );
    $my_account_url = wc_get_page_permalink( 'myaccount' );
    $activation_link = add_query_arg( array(
        'rima_activate' => $customer_id,
        'hash'          => $activation_hash
    ), $my_account_url );
    
    $subject = "Confirm Your Account - RIMA Academy";
    
    // HTML Email Template
    ob_start(); ?>
    <div style="background:linear-gradient(135deg,#C8102E 0%,#8B0A1E 100%);padding:32px 40px;text-align:center;">
        <div style="font-size:48px;line-height:1;margin-bottom:12px;">&#128231;</div>
        <h1 style="color:#fff;font-size:24px;font-weight:800;line-height:1.3;margin:0;font-family:Arial,sans-serif;">Activate Your Account</h1>
        <p style="color:rgba(255,255,255,.85);font-size:14px;margin-top:10px;line-height:1.6;font-family:Arial,sans-serif;">Just one more step to start your language journey.</p>
    </div>
    <div style="background:#1A2E45;padding:36px 40px;font-family:Arial,sans-serif;">
        <p style="color:#fff;font-size:17px;font-weight:600;margin-bottom:16px;">Hi <?php echo esc_html( $user->display_name ?: $user->user_login ); ?>,</p>
        <p style="color:rgba(255,255,255,.8);font-size:15px;line-height:1.7;margin-bottom:16px;">Thank you for joining RIMA Academy! Please verify your email address to activate your account and access all our courses and features.</p>
        
        <div style="text-align:center;margin:35px 0;">
            <a href="<?php echo esc_url_raw($activation_link); ?>" style="display:inline-block;background:linear-gradient(135deg,#C8102E 0%,#8B0A1E 100%);color:#fff;font-size:16px;font-weight:700;padding:16px 45px;border-radius:50px;letter-spacing:0.5px;text-decoration:none;box-shadow:0 8px 24px rgba(200,16,46,0.4);">Verify Email Address</a>
        </div>
        
        <p style="color:rgba(255,255,255,.5);font-size:13px;line-height:1.5;margin-bottom:0;">If the button doesn't work, copy and paste this link into your browser:<br><br><a href="<?php echo esc_url_raw($activation_link); ?>" style="color:#C8102E;word-break:break-all;"><?php echo esc_url_raw($activation_link); ?></a></p>
    </div>
    <?php
    $message_html = ob_get_clean();
    
    if ( function_exists('rima_send_email') ) {
        rima_send_email( $user->user_email, $subject, $message_html, 'Please verify your email address to activate your account.' );
    } else {
        // Fallback if the function is missing for some reason
        $headers = array('Content-Type: text/html; charset=UTF-8');
        wp_mail( $user->user_email, $subject, $message_html, $headers );
    }
}

// 2. Add notice after registration redirect
add_filter( 'woocommerce_registration_redirect', 'rima_registration_redirect_notice' );
function rima_registration_redirect_notice( $redirect ) {
    wc_add_notice( __('Registration successful! Please check your email inbox to activate your account.', 'woocommerce'), 'success' );
    return wc_get_page_permalink( 'myaccount' );
}

// 3. Block login if unverified
add_filter( 'woocommerce_process_login_errors', 'rima_prevent_unverified_login', 10, 3 );
function rima_prevent_unverified_login( $validation_error, $login, $password ) {
    $user = get_user_by( 'login', $login );
    if ( ! $user ) {
        $user = get_user_by( 'email', $login );
    }
    
    if ( $user ) {
        $is_activated = get_user_meta( $user->ID, 'rima_is_activated', true );
        if ( $is_activated === '0' ) {
            $validation_error->add( 'unverified_account', __('You must verify your email address before logging in. Please check your inbox.', 'woocommerce') );
        }
    }
    return $validation_error;
}

// 4. Handle activation link click
add_action( 'template_redirect', 'rima_process_email_verification' );
function rima_process_email_verification() {
    if ( isset( $_GET['rima_activate'] ) && isset( $_GET['hash'] ) ) {
        $user_id = intval( $_GET['rima_activate'] );
        $hash    = sanitize_text_field( $_GET['hash'] );
        
        $stored_hash = get_user_meta( $user_id, 'rima_activation_hash', true );
        if ( $stored_hash === $hash && !empty($hash) ) {
            update_user_meta( $user_id, 'rima_is_activated', '1' );
            delete_user_meta( $user_id, 'rima_activation_hash' );
            wc_add_notice( __('Your account has been successfully verified! You can now log in.', 'woocommerce'), 'success' );
            
            wp_redirect( wc_get_page_permalink( 'myaccount' ) );
            exit;
        } else {
            wc_add_notice( __('Invalid or expired activation link.', 'woocommerce'), 'error' );
            wp_redirect( wc_get_page_permalink( 'myaccount' ) );
            exit;
        }
    }
}

/* ============================================================
   12. DIRECT BANK TRANSFER (BACS) PAYMENT PROOF UPLOAD
   ============================================================ */

// Display upload box on view order page
add_action( 'woocommerce_order_details_after_order_table', 'rima_add_payment_proof_upload_section', 10, 1 );
function rima_add_payment_proof_upload_section( $order ) {
    if ( ! is_a( $order, 'WC_Order' ) ) return;
    if ( $order->get_payment_method() !== 'bacs' ) return;
    
    $allowed_statuses = array( 'on-hold', 'pending', 'failed' );
    $order_status = $order->get_status();
    $proof_id = get_post_meta( $order->get_id(), '_rima_payment_proof', true );
    $proof_url = $proof_id ? wp_get_attachment_url( $proof_id ) : '';

    if ( ! in_array( $order_status, $allowed_statuses ) ) {
        if ( $proof_id ) {
            ?>
            <div class="rima-proof-container success-uploaded mt-4 p-4 rounded-4 border bg-white shadow-sm">
                <h4 class="h5 fw-bold mb-2 text-dark">
                    <span class="rima-en">Payment Proof</span>
                    <span class="rima-ro">Dovadă Plată</span>
                </h4>
                <p class="text-muted small">
                    <span class="rima-en">The payment proof has been uploaded and verified.</span>
                    <span class="rima-ro">Dovada de plată a fost trimisă și verificată.</span>
                </p>
                <a href="<?php echo esc_url($proof_url); ?>" target="_blank" class="btn btn-outline-primary btn-sm rounded-3">
                    <i class="fa fa-file-text-o me-2"></i><?php _e('Vizualizează dovada', 'rima-academy'); ?>
                </a>
            </div>
            <?php
        }
        return;
    }

    ?>
    <div class="rima-proof-container mt-4 p-4 rounded-4 border bg-white shadow-sm">
        <h4 class="h5 fw-bold mb-2 text-dark">
            <span class="rima-en">Upload Payment Proof</span>
            <span class="rima-ro">Încarcă Dovada Plății</span>
        </h4>
        <p class="text-muted small mb-3">
            <span class="rima-en">For direct bank transfer orders, please upload a copy of the payment receipt (PDF, PNG, JPG - max 5MB) to speed up course activation.</span>
            <span class="rima-ro">Pentru plățile prin transfer bancar, te rugăm să încarci o copie a dovezii de plată (PDF, PNG, JPG - max 5MB) pentru a grăbi activarea contului.</span>
        </p>

        <div class="rima-upload-box p-4 border border-2 border-dashed rounded-3 text-center position-relative <?php echo $proof_id ? 'has-file' : ''; ?>" id="rima-proof-dropzone" style="cursor: pointer; border-color: #cbd5e1; background-color: #f8fafc; transition: all 0.3s ease;">
            <input type="file" id="rima-proof-file-input" accept="application/pdf,image/png,image/jpeg,image/jpg" class="position-absolute top-0 start-0 w-100 h-100 opacity-0 cursor-pointer" style="z-index: 2; cursor: pointer;">
            
            <div class="rima-upload-box-idle" style="<?php echo $proof_id ? 'display:none;' : ''; ?>">
                <i class="fa fa-cloud-upload text-muted mb-2" style="font-size: 32px;"></i>
                <p class="mb-1 fw-semibold text-dark">
                    <span class="rima-en">Click to upload or drag & drop</span>
                    <span class="rima-ro">Apasă pentru a alege fișierul sau trage-l aici</span>
                </p>
                <span class="text-muted small">PDF, PNG, JPG (max 5MB)</span>
            </div>

            <div class="rima-upload-box-success" style="<?php echo $proof_id ? '' : 'display:none;'; ?>">
                <i class="fa fa-check-circle text-success mb-2" style="font-size: 32px;"></i>
                <p class="mb-1 fw-semibold text-success">
                    <span class="rima-en">Proof Uploaded Successfully</span>
                    <span class="rima-ro">Dovada a fost încărcată cu succes</span>
                </p>
                <div class="d-flex justify-content-center gap-2 mt-2 position-relative" style="z-index: 3;">
                    <a href="<?php echo esc_url($proof_url); ?>" id="rima-proof-preview-link" target="_blank" class="btn btn-sm btn-outline-secondary rounded-2" style="<?php echo $proof_url ? '' : 'display:none;'; ?>">
                        <i class="fa fa-eye"></i> <span class="rima-en">View File</span><span class="rima-ro">Vezi Fișier</span>
                    </a>
                    <button type="button" id="rima-proof-change-btn" class="btn btn-sm btn-outline-danger rounded-2">
                        <i class="fa fa-refresh"></i> <span class="rima-en">Change File</span><span class="rima-ro">Schimbă Fișier</span>
                    </button>
                </div>
            </div>
            
            <div class="rima-upload-box-progress" style="display: none;">
                <div class="spinner-border text-primary mb-2" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mb-0 fw-semibold text-primary">Se încarcă fișierul...</p>
            </div>
        </div>
        <div id="rima-proof-error-msg" class="text-danger small mt-2" style="display: none;"></div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        const dropzone = $('#rima-proof-dropzone');
        const fileInput = $('#rima-proof-file-input');
        const idleState = $('.rima-upload-box-idle');
        const successState = $('.rima-upload-box-success');
        const progressState = $('.rima-upload-box-progress');
        const errorMsg = $('#rima-proof-error-msg');
        const previewLink = $('#rima-proof-preview-link');
        const orderId = <?php echo $order->get_id(); ?>;

        fileInput.on('change', function() {
            const file = this.files[0];
            if (!file) return;

            // Validate file type
            const allowedTypes = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg'];
            if (!allowedTypes.includes(file.type)) {
                errorMsg.text('Format invalid. Sunt permise doar fișiere PDF, PNG și JPG.').show();
                return;
            }

            // Validate size (5MB)
            if (file.size > 5 * 1024 * 1024) {
                errorMsg.text('Fișierul este prea mare. Lăsați dimensiunea maximă de 5MB.').show();
                return;
            }

            errorMsg.hide();
            idleState.hide();
            successState.hide();
            progressState.show();

            const formData = new FormData();
            formData.append('proof_file', file);
            formData.append('order_id', orderId);
            formData.append('action', 'rima_upload_payment_proof');
            formData.append('nonce', '<?php echo wp_create_nonce("rima_proof_nonce_" . $order->get_id()); ?>');

            $.ajax({
                url: '<?php echo admin_url("admin-ajax.php"); ?>',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    progressState.hide();
                    if (response.success) {
                        previewLink.attr('href', response.data.url);
                        previewLink.show();
                        successState.show();
                        dropzone.addClass('has-file');
                    } else {
                        idleState.show();
                        errorMsg.text(response.data || 'A apărut o eroare la încărcare.').show();
                    }
                },
                error: function() {
                    progressState.hide();
                    idleState.show();
                    errorMsg.text('Eroare de rețea. Te rugăm să încerci din nou.').show();
                }
            });
        });

        $('#rima-proof-change-btn').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            fileInput.val('');
            dropzone.removeClass('has-file');
            successState.hide();
            idleState.show();
        });
    });
    </script>
    <style>
    .rima-upload-box:hover {
        border-color: #102d56 !important;
        background-color: #f1f5f9 !important;
    }
    .rima-upload-box.has-file {
        border-style: solid !important;
        border-color: #10b981 !important;
        background-color: #f0fdf4 !important;
    }
    .cursor-pointer { cursor: pointer; }
    </style>
    <?php
}

// Handle AJAX Upload request
add_action( 'wp_ajax_rima_upload_payment_proof', 'rima_ajax_handle_payment_proof_upload' );
function rima_ajax_handle_payment_proof_upload() {
    $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
    
    if ( ! $order_id ) {
        wp_send_json_error( 'Comandă invalidă.' );
    }

    // Verify nonce
    check_ajax_referer( 'rima_proof_nonce_' . $order_id, 'nonce' );

    if ( ! is_user_logged_in() ) {
        wp_send_json_error( 'Nu ești autentificat.' );
    }

    $order = wc_get_order( $order_id );
    if ( ! $order ) {
        wp_send_json_error( 'Comanda nu a fost găsită.' );
    }

    // Verify ownership
    if ( $order->get_customer_id() !== get_current_user_id() ) {
        wp_send_json_error( 'Nu ai permisiunea de a modifica această comandă.' );
    }

    if ( empty($_FILES['proof_file']) ) {
        wp_send_json_error( 'Niciun fișier selectat.' );
    }

    $file = $_FILES['proof_file'];

    // Types
    $allowed_types = array( 'application/pdf', 'image/png', 'image/jpeg', 'image/jpg' );
    if ( ! in_array( $file['type'], $allowed_types ) ) {
        wp_send_json_error( 'Format de fișier nepermis. Doar PDF, PNG sau JPG.' );
    }

    // Size
    if ( $file['size'] > 5 * 1024 * 1024 ) {
        wp_send_json_error( 'Fișierul depășește limita de 5MB.' );
    }

    require_once( ABSPATH . 'wp-admin/includes/image.php' );
    require_once( ABSPATH . 'wp-admin/includes/file.php' );
    require_once( ABSPATH . 'wp-admin/includes/media.php' );

    $attachment_id = media_handle_upload( 'proof_file', $order_id );

    if ( is_wp_error( $attachment_id ) ) {
        wp_send_json_error( 'Eroare la salvare: ' . $attachment_id->get_error_message() );
    }

    update_post_meta( $order_id, '_rima_payment_proof', $attachment_id );

    wp_send_json_success( array(
        'url' => wp_get_attachment_url( $attachment_id )
    ) );
}

// Add Admin Metabox to show the payment proof in WooCommerce order details page
add_action( 'add_meta_boxes', 'rima_add_order_payment_proof_metabox' );
function rima_add_order_payment_proof_metabox() {
    // Screen compatibility for HPOS & standard tables
    $screen = class_exists( 'Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrderStatusTableController' ) && 
              method_exists('Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrderStatusTableController', 'is_active') &&
              Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrderStatusTableController::is_active() 
              ? wc_get_page_screen_id( 'shop-order' ) 
              : 'shop_order';

    add_meta_box(
        'rima_payment_proof_box',
        '📄 Dovadă Plată / Payment Proof',
        'rima_render_payment_proof_metabox',
        $screen,
        'side',
        'default'
    );
}

function rima_render_payment_proof_metabox( $post_or_order_object ) {
    // Resolve order depending on HPOS or normal meta boxes
    $order = ( $post_or_order_object instanceof WP_Post ) ? wc_get_order( $post_or_order_object->ID ) : $post_or_order_object;
    if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
        echo '<p>Comandă invalidă.</p>';
        return;
    }

    if ( $order->get_payment_method() !== 'bacs' ) {
        echo '<p class="description">Această comandă nu folosește ca metodă de plată Transferul Bancar.</p>';
        return;
    }

    $proof_id = get_post_meta( $order->get_id(), '_rima_payment_proof', true );

    if ( ! $proof_id ) {
        echo '<div class="notice notice-warning inline" style="margin: 0 0 10px 0; padding: 8px;"><p style="margin: 0;">⚠️ Utilizatorul nu a încărcat încă dovada de plată.</p></div>';
        return;
    }

    $proof_url = wp_get_attachment_url( $proof_id );
    $file_path = get_attached_file( $proof_id );
    $file_ext  = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));

    echo '<div style="margin-bottom: 12px;">';
    echo '<p style="margin-top: 0;"><strong>Dovadă încărcată:</strong></p>';
    
    if ( in_array( $file_ext, array('png', 'jpg', 'jpeg') ) ) {
        echo '<a href="' . esc_url($proof_url) . '" target="_blank">';
        echo '<img src="' . esc_url($proof_url) . '" style="max-width: 100%; border: 1px solid #ddd; border-radius: 4px; margin-bottom: 8px; display: block;" />';
        echo '</a>';
    } else {
        echo '<div style="background: #f1f1f1; padding: 12px; border-radius: 4px; text-align: center; margin-bottom: 8px;">';
        echo '<span class="dashicons dashicons-pdf" style="font-size: 40px; width: 40px; height: 40px; color: #d63636; line-height:1;"></span>';
        echo '<p style="margin: 5px 0 0 0; font-size: 12px;">Fișier PDF</p>';
        echo '</div>';
    }

    echo '<a href="' . esc_url($proof_url) . '" target="_blank" class="button button-primary button-large" style="width: 100%; text-align: center;">';
    echo '<span class="dashicons dashicons-visibility" style="margin-top: 4px;"></span> Deschide / Descarcă Dovada';
    echo '</a>';
    echo '</div>';
}

// Force "Apply Now" button to directly Add to Cart on Course Pages
add_action('wp_footer', function() {
    if (is_singular('course')) {
        global $post;
        // Academist LMS usually links a WooCommerce product ID in post meta
        $product_id = get_post_meta($post->ID, 'eltdf_course_woo_product_meta', true);
        
        // Output JS to override the Apply Now button regardless
        ?>
        <script>
        jQuery(document).ready(function($) {
            var productId = '<?php echo esc_js($product_id); ?>';
            if (!productId) return;

            function doAjaxAddToCart($btn, productId) {
                var isRo = $('body').hasClass('rima-lang-ro') || (localStorage.getItem('rima_lang') === 'ro');
                var originalText = $btn.text();
                $btn.text(isRo ? 'Se adaugă...' : 'Adding...');
                $btn.css({'opacity': '0.7', 'pointer-events': 'none'});
                
                // Use our custom silent endpoint to prevent WC notices from saving in the session
                        // Trigger fragment refresh to update cart counters
                        $(document.body).trigger('wc_fragment_refresh');
                        
                        var productName = $('.rsc-hero-title').text().trim() || 'Course';
                        var msg = isRo ? '"' + productName + '" a fost adăugat în coș!' : '"' + productName + '" has been added to cart!';
                        
                        var $toast = $('#rima-cart-toast');
                        if($toast.length) {
                            $toast.text(msg).addClass('show-toast');
                            setTimeout(function() {
                                $toast.removeClass('show-toast');
                            }, 4000);
                        }
                        
                        // Bounce the header cart icon
                        var $cartHolder = $('.eltdf-shopping-cart-holder');
                        if($cartHolder.length) {
                            $cartHolder.addClass('rima-cart-bounce');
                            setTimeout(function() {
                                $cartHolder.removeClass('rima-cart-bounce');
                            }, 400);
                        }
                    } else {
                        var errMsg = 'Error adding to cart.';
                        if (response && response.data && response.data.message) {
                            errMsg = response.data.message;
                        }
                        alert(errMsg);
                        $btn.text(originalText);
                        $btn.css({'opacity': '1', 'pointer-events': 'auto'});
                    }
                }).fail(function() {
                    $btn.text(originalText);
                    $btn.css({'opacity': '1', 'pointer-events': 'auto'});
                });
            }

            // 1. Intercept standard WooCommerce cart form (Logged In Users)
            $('form.cart').on('submit', function(e) {
                e.preventDefault();
                var $btn = $(this).find('button[type="submit"]');
                doAjaxAddToCart($btn, productId);
            });

            // 2. Intercept Academist login/apply buttons (Logged Out Users)
            var $applyBtns = $('.eltdf-lms-buy-button, .eltdf-btn[href*="user-dashboard"]');
            if ($applyBtns.length) {
                $applyBtns.each(function() {
                    var $originalBtn = $(this);
                    var $clone = $originalBtn.clone(false); // Clone without events
                    $clone.removeClass('eltdf-lms-buy-button eltdf-lms-buy-button-opened');
                    $clone.addClass('rima-custom-add-to-cart');
                    $clone.attr('href', 'javascript:void(0);');
                    $originalBtn.replaceWith($clone);
                });
                
                // Use event delegation on the cloned buttons
                $(document).off('click', '.rima-custom-add-to-cart').on('click', '.rima-custom-add-to-cart', function(e) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    doAjaxAddToCart($(this), productId);
                });
            }

            // Force "View Cart" to say "Add to Cart" for consistency on reload
            $('.eltdf-btn').each(function() {
                var txt = $(this).text().trim().toLowerCase();
                if (txt === 'view cart' || txt === 'apply now') {
                    var isRo = $('body').hasClass('rima-lang-ro');
                    $(this).text(isRo ? 'Adaugă în Coș' : 'Add to Cart');
                }
            });
            
            // Hide standard WooCommerce notices on this page if they appear on load
            $('.woocommerce-notices-wrapper, .woocommerce-message, .woocommerce-error, .woocommerce-info').hide();
        });
        </script>
        <?php
    }
}, 999);

/**
 * ==============================================================
 * RIMA ACADEMY: Auto-sync LMS Courses with WooCommerce Products
 * ==============================================================
 */
add_action('save_post_course', 'rima_auto_sync_course_with_woo', 10, 3);
function rima_auto_sync_course_with_woo($post_id, $post, $update) {
    // Don't run on autosave or revisions
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id)) return;
    
    // Check if it's a valid course
    if ($post->post_status !== 'publish' && $post->post_status !== 'draft') return;

    // Get the course price from Academist meta 
    $price = get_post_meta($post_id, 'eltdf_course_price_meta', true);
    if (empty($price)) $price = '0'; 

    // Check if a product is already linked
    $product_id = get_post_meta($post_id, 'eltdf_course_woo_product_meta', true);
    $product = $product_id ? wc_get_product($product_id) : false;
    $thumbnail_id = get_post_thumbnail_id($post_id);

    if ($product_id && $product) {
        // Update existing product price, title, image
        $product->set_regular_price($price);
        $product->set_name($post->post_title);
        if ($thumbnail_id) {
            $product->set_image_id($thumbnail_id);
        }
        $product->save();
        update_post_meta($product_id, '_rima_linked_course_id', $post_id);
    } else {
        // Create new hidden virtual product
        $product = new WC_Product_Simple();
        $product->set_name($post->post_title);
        $product->set_status('publish');
        $product->set_catalog_visibility('hidden');
        $product->set_virtual(true);
        $product->set_sold_individually(true); // Can only buy one of each course
        $product->set_regular_price($price);
        if ($price > 0) {
            $product->set_price($price);
        }
        if ($thumbnail_id) {
            $product->set_image_id($thumbnail_id);
        }
        
        $new_product_id = $product->save();

        if ($new_product_id) {
            // Link it to the course natively for Academist
            update_post_meta($post_id, 'eltdf_course_woo_product_meta', $new_product_id);
            // Optionally link product back to course
            update_post_meta($new_product_id, '_rima_linked_course_id', $post_id);
        }
    }
}

// Admin Trigger to sync all existing courses (Run once)
add_action('admin_init', function() {
    if (isset($_GET['rima_sync_courses']) && current_user_can('manage_options')) {
        $courses = get_posts(array(
            'post_type' => 'course',
            'posts_per_page' => -1,
            'post_status' => 'any'
        ));
        foreach ($courses as $course) {
            rima_auto_sync_course_with_woo($course->ID, $course, true);
        }
        wp_die('Toate cursurile (' . count($courses) . ') au fost sincronizate cu WooCommerce și li s-au creat produse ascunse! Poti inchide aceasta pagina și verifica pe site.');
    }
});

// Bypass stubborn page caches (Cloudflare/WP Rocket) by injecting the JS fix via WooCommerce AJAX fragments!
// Since WooCommerce AJAX is never cached, this guarantees the script runs for all users, even on cached HTML pages.
add_filter('woocommerce_add_to_cart_fragments', function($fragments) {
    $inject_js = '<script>
        document.addEventListener("click", function(e) {
            var cartTarget = e.target.closest(".eltdf-shopping-cart-holder, .eltdf-header-cart, .eltdf-cart-icon");
            if (cartTarget) {
                e.preventDefault();
                e.stopPropagation();
                var sideCart = document.getElementById("rima-side-cart");
                var overlay = document.getElementById("rima-side-cart-overlay");
                if (sideCart) sideCart.classList.add("rima-cart-open");
                if (overlay) overlay.classList.add("rima-cart-open");
            }
        }, true);
        
        var sv = \'<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>\';
        var iconNode = document.querySelector(".eltdf-cart-icon");
        if(iconNode) iconNode.innerHTML = sv;
    </script>';

    if (is_array($fragments)) {
        foreach ($fragments as $key => $html) {
            if (strpos($html, 'eltdf-cart-icon') !== false) {
                $fragments[$key] .= $inject_js;
                break; // only inject once
            }
        }
    }
    return $fragments;
}, 999);

add_action('template_redirect', function() {
    if (function_exists('is_shop') && is_shop()) {
        wp_safe_redirect(home_url('/our-courses/'), 301);
        exit;
    }
    
    // Only redirect product pages on GET requests to allow POST form submissions (like Add to Cart) to process
    if (is_singular('product') && $_SERVER['REQUEST_METHOD'] !== 'POST') {
        $product_id = get_the_ID();
        $courses = get_posts(array(
            'post_type' => 'course',
            'meta_key' => 'eltdf_course_woo_product_meta',
            'meta_value' => $product_id,
            'posts_per_page' => 1
        ));
        if (!empty($courses)) {
            wp_safe_redirect(get_permalink($courses[0]->ID), 301);
            exit;
        }
    }
});

/**
 * ==============================================================
 * RIMA ACADEMY: Make single course Add to Cart form submit to current course URL
 * ==============================================================
 */
add_filter('woocommerce_add_to_cart_form_action', function($action) {
    if (is_singular('course')) {
        return ''; // submitting to empty action posts to the current page URL
    }
    return $action;
}, 99);

/**
 * ==============================================================
 * RIMA ACADEMY: Enqueue WooCommerce AJAX Add to Cart script on course listing/archive and single course pages
 * ==============================================================
 */
add_action('wp_enqueue_scripts', function() {
    if (is_singular('course') || is_post_type_archive('course') || is_page('our-courses')) {
        if (function_exists('is_woocommerce')) {
            wp_enqueue_script('wc-add-to-cart');
        }
    }
}, 30);

/**
 * ==============================================================
 * RIMA ACADEMY: Force Child Theme's single-course.php template
 * ==============================================================
 */
add_filter('single_template', function($template) {
    global $post;
    if (!empty($post) && $post->post_type === 'course') {
        $child_template = get_stylesheet_directory() . '/single-course.php';
        if (file_exists($child_template)) {
            return $child_template;
        }
    }
    return $template;
}, 999);

/**
 * ==============================================================
 * RIMA ACADEMY: Remove Forum Tab from Single Course Page
 * ==============================================================
 */
add_filter('academist_elated_filter_single_course_tabs', function($tabs) {
    if (isset($tabs['forum'])) {
        unset($tabs['forum']);
    }
    return $tabs;
}, 99);


/* ============================================================
   2026 — OUR COURSES LISTING: Enqueue & AJAX handler
   ============================================================ */

/**
 * Enqueue assets for Our Courses listing page & single course page
 */
add_action( 'wp_enqueue_scripts', 'rima_enqueue_2026_course_assets', 25 );
function rima_enqueue_2026_course_assets() {
    $theme_uri = get_stylesheet_directory_uri();
    $ver       = wp_get_theme()->get( 'Version' );

    // ── Our Courses listing page ──────────────────────────
    if ( is_page( 'our-courses' ) || is_page_template( 'page-our-courses.php' ) ) {
        wp_enqueue_style(
            'rima-courses',
            $theme_uri . '/assets/css/rima-courses.css',
            array(),
            '1.0.3'
        );
        wp_enqueue_script(
            'rima-courses',
            $theme_uri . '/assets/js/rima-courses.js',
            array(),
            $ver,
            true
        );
        wp_localize_script( 'rima-courses', 'rimaCourses', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'rima_courses_filter' ),
        ) );
    }

    // ── Single Course ─────────────────────────────────────
    if ( is_singular( 'course' ) ) {
        wp_enqueue_style(
            'rima-courses',
            $theme_uri . '/assets/css/rima-courses.css',
            array(),
            $ver
        );
        wp_enqueue_style(
            'rima-single-course',
            $theme_uri . '/assets/css/rima-single-course.css',
            array( 'rima-courses' ),
            $ver
        );
        wp_enqueue_script(
            'rima-single-course',
            $theme_uri . '/assets/js/rima-single-course.js',
            array(),
            $ver,
            true
        );
    }
}

/**
 * AJAX handler — filter / search / sort courses
 */
add_action( 'wp_ajax_rima_filter_courses',        'rima_ajax_filter_courses' );
add_action( 'wp_ajax_nopriv_rima_filter_courses', 'rima_ajax_filter_courses' );

function rima_ajax_filter_courses() {
    check_ajax_referer( 'rima_courses_filter', 'nonce' );

    $category = sanitize_text_field( $_POST['category'] ?? '' );
    $search   = sanitize_text_field( $_POST['search']   ?? '' );
    $sort     = sanitize_text_field( $_POST['sort']     ?? 'title_asc' );
    $page     = max( 1, intval( $_POST['page']     ?? 1 ) );
    $per_page = max( 1, intval( $_POST['per_page'] ?? 9 ) );

    // Build orderby
    $orderby = 'date';
    $order   = 'DESC';
    switch ( $sort ) {
        case 'oldest':
            $order = 'ASC';
            break;
        case 'title_asc':
            $orderby = 'title';
            $order   = 'ASC';
            break;
        case 'title_desc':
            $orderby = 'title';
            $order   = 'DESC';
            break;
    }

    $args = array(
        'post_type'      => 'course',
        'post_status'    => 'publish',
        'posts_per_page' => $per_page,
        'paged'          => $page,
        'orderby'        => $orderby,
        'order'          => $order,
        's'              => $search,
    );

    if ( $category ) {
        $args['tax_query'] = array( array(
            'taxonomy' => 'course-category',
            'field'    => 'slug',
            'terms'    => $category,
        ) );
    }

    $query = new WP_Query( $args );

    if ( ! $query->have_posts() ) {
        wp_send_json_success( array(
            'html'  => '',
            'found' => 0,
            'total' => wp_count_posts( 'course' )->publish,
            'pages' => 0,
        ) );
        return;
    }

    ob_start();

    while ( $query->have_posts() ) {
        $query->the_post();

        $cid         = get_the_ID();
        $cats        = get_the_terms( $cid, 'course-category' );
        $cat_name    = ( ! is_wp_error( $cats ) && ! empty( $cats ) ) ? $cats[0]->name : '';
        $price       = function_exists( 'academist_lms_calculate_course_price' ) ? academist_lms_calculate_course_price( $cid ) : 0;
        $thumb       = get_the_post_thumbnail_url( $cid, 'medium_large' );
        $instr_id    = get_post_meta( $cid, 'eltdf_course_instructor_meta', true );
        $instr_name  = $instr_id ? get_the_title( $instr_id ) : '';
        $duration    = get_post_meta( $cid, 'eltdf_course_duration', true );
        $lessons     = get_post_meta( $cid, 'eltdf_course_lessons_count', true );
        $certificate = get_post_meta( $cid, 'eltdf_course_certificate', true );

        // Price label
        if ( $price == 0 ) {
            $price_badge = '<span class="roc-card-badge-price roc-badge-free"><span class="rima-en">Free</span><span class="rima-ro">Gratuit</span></span>';
        } elseif ( function_exists( 'get_woocommerce_currency_symbol' ) ) {
            $pos = get_option( 'woocommerce_currency_pos', 'right' );
            $sym = get_woocommerce_currency_symbol();
            $pl  = $pos === 'left' ? $sym . $price : $price . ' ' . $sym;
            $price_badge = '<span class="roc-card-badge-price">' . esc_html( $pl ) . '</span>';
        } else {
            $price_badge = '<span class="roc-card-badge-price">' . esc_html( $price ) . '</span>';
        }

        ?>
        <article class="roc-card" data-cat="<?php echo esc_attr( $cats && ! is_wp_error( $cats ) ? $cats[0]->slug : '' ); ?>">
            <a href="<?php the_permalink(); ?>" class="roc-card-image-link" tabindex="-1">
                <div class="roc-card-image">
                    <?php if ( $thumb ) : ?>
                        <img src="<?php echo esc_url( $thumb ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" loading="lazy" />
                    <?php else : ?>
                        <div class="roc-card-image-placeholder">
                            <svg width="56" height="56" fill="none" viewBox="0 0 24 24" stroke="rgba(255,255,255,0.18)" stroke-width="1"><path d="M12 14l9-5-9-5-9 5 9 5z"/></svg>
                        </div>
                    <?php endif; ?>
                    <?php if ( $cat_name ) : ?>
                        <span class="roc-card-badge-cat"><?php echo esc_html( $cat_name ); ?></span>
                    <?php endif; ?>
                    <?php echo $price_badge; ?>
                </div>
            </a>
            <div class="roc-card-body">
                <h3 class="roc-card-title">
                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                </h3>
                <?php if ( $instr_name ) : ?>
                    <div class="roc-card-instructor">
                        <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        <?php echo esc_html( $instr_name ); ?>
                    </div>
                <?php endif; ?>
                <p class="roc-card-excerpt"><?php echo wp_kses_post( wp_trim_words( get_the_excerpt() ?: get_the_content(), 18 ) ); ?></p>
                <!-- List-mode meta -->
                <div class="roc-card-meta-row">
                    <?php if ( $duration ) : ?>
                        <span class="roc-meta-item">
                            <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                            <?php echo esc_html( $duration ); ?>
                        </span>
                    <?php endif; ?>
                    <?php if ( $lessons ) : ?>
                        <span class="roc-meta-item">
                            <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/></svg>
                            <?php echo esc_html( $lessons ); ?> <span class="rima-en">lessons</span><span class="rima-ro">lecții</span>
                        </span>
                    <?php endif; ?>
                    <?php if ( $certificate ) : ?>
                        <span class="roc-meta-item">
                            <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>
                            <span class="rima-en">Certificate</span><span class="rima-ro">Certificat</span>
                        </span>
                    <?php endif; ?>
                </div>
                <a href="<?php the_permalink(); ?>" class="roc-card-cta eltdf-btn eltdf-btn-solid rima-btn-blue">
                    <span class="rima-en">View Course</span>
                    <span class="rima-ro">Vezi Cursul</span>
                    <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </a>
            </div>
        </article>
        <?php
    }

    wp_reset_postdata();
    $html = ob_get_clean();

    wp_send_json_success( array(
        'html'  => $html,
        'found' => $query->post_count,
        'total' => $query->found_posts,
        'pages' => $query->max_num_pages,
    ) );
}

/**
 * SPA Iframe Mode for Dashboard Lesson Viewer
 * Hides all theme headers, footers, and padding when ?rima_iframe=1 is present.
 */
add_action( 'wp_head', 'rima_spa_iframe_mode' );
function rima_spa_iframe_mode() {
    if ( isset( $_GET['rima_iframe'] ) && $_GET['rima_iframe'] === '1' ) {
        echo '<style>
            header.eltdf-page-header, 
            footer, 
            .eltdf-mobile-header,
            .eltdf-title-holder,
            .eltdf-top-bar { display: none !important; }
            .eltdf-wrapper-inner { padding: 0 !important; margin: 0 !important; }
            .eltdf-content { margin-top: 0 !important; }
            body { background: #fff !important; overflow-x: hidden; padding-top: 0 !important; }
            .eltdf-container-inner { width: 100% !important; max-width: 100% !important; padding: 20px !important; }
            
            /* Academist LMS specific overrides for full width lesson */
            .eltdf-lms-single-lesson .eltdf-lms-lesson-content { margin: 0 auto; max-width: 900px; padding-bottom: 50px; }
            .eltdf-lms-single-quiz .eltdf-lms-quiz-content { margin: 0 auto; max-width: 900px; padding-bottom: 50px; }
            
            /* Hide the Academist native back-to-course button and breadcrumbs if present */
            .eltdf-lms-single-lesson .eltdf-lms-lesson-back-btn { display: none !important; }
        </style>';
    }
}

/* ============================================================
   RIMA DYNAMIC GLOBE MARKERS
   Generates JSON marker data based on active 'course-category' terms
   ============================================================ */
function rima_get_globe_markers_json() {
    $globe_dict = array(
        'english'    => array('aliases' => array('english', 'engleza'), 'lat' => 51.5072,  'lng' => -0.1276,  'flag' => 'https://flagcdn.com/w40/gb.png', 'isos' => array('GBR', 'USA', 'CAN', 'AUS'), 'label' => 'English'),
        'romanian'   => array('aliases' => array('romanian', 'romana'), 'lat' => 45.9432,  'lng' => 24.9668,  'flag' => 'https://flagcdn.com/w40/ro.png', 'isos' => array('ROU', 'MDA'), 'label' => 'Romanian'),
        'japanese'   => array('aliases' => array('japanese', 'japoneza'), 'lat' => 36.2048,  'lng' => 138.2529, 'flag' => 'https://flagcdn.com/w40/jp.png', 'isos' => array('JPN'), 'label' => 'Japanese'),
        'spanish'    => array('aliases' => array('spanish', 'spaniola'), 'lat' => 40.4637,  'lng' => -3.7492,  'flag' => 'https://flagcdn.com/w40/es.png', 'isos' => array('ESP', 'MEX', 'ARG', 'COL', 'PER', 'CHL'), 'label' => 'Spanish'),
        'french'     => array('aliases' => array('french', 'franceza'), 'lat' => 46.2276,  'lng' => 2.2137,   'flag' => 'https://flagcdn.com/w40/fr.png', 'isos' => array('FRA', 'CAN', 'BEL', 'CHE', 'CMR'), 'label' => 'French'),
        'german'     => array('aliases' => array('german', 'germana'), 'lat' => 51.1657,  'lng' => 10.4515,  'flag' => 'https://flagcdn.com/w40/de.png', 'isos' => array('DEU', 'AUT', 'CHE'), 'label' => 'German'),
        'italian'    => array('aliases' => array('italian', 'italiana'), 'lat' => 41.8719,  'lng' => 12.5674,  'flag' => 'https://flagcdn.com/w40/it.png', 'isos' => array('ITA', 'CHE'), 'label' => 'Italian'),
        'chinese'    => array('aliases' => array('chinese', 'chineza'), 'lat' => 35.8617,  'lng' => 104.1954, 'flag' => 'https://flagcdn.com/w40/cn.png', 'isos' => array('CHN', 'TWN', 'SGP'), 'label' => 'Chinese'),
        'arabic'     => array('aliases' => array('arabic', 'araba'), 'lat' => 23.8859,  'lng' => 45.0792,  'flag' => 'https://flagcdn.com/w40/sa.png', 'isos' => array('SAU', 'EGY', 'ARE', 'MAR', 'DZA'), 'label' => 'Arabic'),
        'portuguese' => array('aliases' => array('portuguese', 'portugheza'), 'lat' => -14.235,  'lng' => -51.9253, 'flag' => 'https://flagcdn.com/w40/pt.png', 'isos' => array('PRT', 'BRA', 'AGO'), 'label' => 'Portuguese'),
        'russian'    => array('aliases' => array('russian', 'rusa'), 'lat' => 61.524,   'lng' => 105.3188, 'flag' => 'https://flagcdn.com/w40/ru.png', 'isos' => array('RUS', 'BLR', 'KAZ'), 'label' => 'Russian'),
        'korean'     => array('aliases' => array('korean', 'coreeana'), 'lat' => 35.9078,  'lng' => 127.7669, 'flag' => 'https://flagcdn.com/w40/kr.png', 'isos' => array('KOR'), 'label' => 'Korean'),
        'dutch'      => array('aliases' => array('dutch', 'olandeza'), 'lat' => 52.1326,  'lng' => 5.2913,   'flag' => 'https://flagcdn.com/w40/nl.png', 'isos' => array('NLD', 'BEL', 'SUR'), 'label' => 'Dutch'),
        'turkish'    => array('aliases' => array('turkish', 'turca'), 'lat' => 38.9637,  'lng' => 35.2433,  'flag' => 'https://flagcdn.com/w40/tr.png', 'isos' => array('TUR'), 'label' => 'Turkish'),
        'hindi'      => array('aliases' => array('hindi'), 'lat' => 20.5937,  'lng' => 78.9629,  'flag' => 'https://flagcdn.com/w40/in.png', 'isos' => array('IND'), 'label' => 'Hindi')
    );

    $found_langs = array();
    
    if ( taxonomy_exists('course-category') ) {
        $course_categories = get_terms(array(
            'taxonomy' => 'course-category',
            'hide_empty' => false
        ));

        if ( ! is_wp_error( $course_categories ) && ! empty( $course_categories ) ) {
            foreach( $course_categories as $term ) {
                $slug = strtolower($term->slug);
                $name = strtolower($term->name);
                
                foreach( $globe_dict as $key => $data ) {
                    $matched = false;
                    foreach ( $data['aliases'] as $alias ) {
                        if( strpos($slug, $alias) !== false || strpos($name, $alias) !== false ) {
                            $matched = true;
                            break;
                        }
                    }
                    if ( $matched ) {
                        if ( ! isset($found_langs[$key]) ) {
                            $found_langs[$key] = array(
                                'lat'   => $data['lat'],
                                'lng'   => $data['lng'],
                                'flag'  => $data['flag'],
                                'label' => $data['label'],
                                'isos'  => $data['isos']
                            );
                        }
                    }
                }
            }
        }
    }

    if ( empty($found_langs) ) {
        foreach( array('english', 'romanian', 'japanese', 'spanish', 'french', 'german') as $def_key ) {
            $data = $globe_dict[$def_key];
            $found_langs[$def_key] = array(
                'lat'   => $data['lat'],
                'lng'   => $data['lng'],
                'flag'  => $data['flag'],
                'label' => $data['label'],
                'isos'  => $data['isos']
            );
        }
    }

    return json_encode(array_values($found_langs));
}


// Remove Addresses from Woo Menu
add_filter( 'woocommerce_account_menu_items', 'rima_remove_addresses_tab', 999 );
function rima_remove_addresses_tab( $items ) {
    if ( isset( $items['edit-address'] ) ) {
        unset( $items['edit-address'] );
    }
    return $items;
}

// -----------------------------------------------------------------------------
// SAVE RIMA CUSTOM REGISTRATION FIELDS (PF / PJ)
// -----------------------------------------------------------------------------
add_action( 'woocommerce_created_customer', 'rima_save_custom_registration_fields', 10, 3 );
function rima_save_custom_registration_fields( $customer_id, $new_customer_data, $password_generated ) {
    
    // Nume / Prenume (comun pentru PF și PJ ca persoană de contact)
    if ( isset( $_POST['billing_first_name'] ) ) {
        update_user_meta( $customer_id, 'billing_first_name', sanitize_text_field( $_POST['billing_first_name'] ) );
        update_user_meta( $customer_id, 'first_name', sanitize_text_field( $_POST['billing_first_name'] ) );
    }
    if ( isset( $_POST['billing_last_name'] ) ) {
        update_user_meta( $customer_id, 'billing_last_name', sanitize_text_field( $_POST['billing_last_name'] ) );
        update_user_meta( $customer_id, 'last_name', sanitize_text_field( $_POST['billing_last_name'] ) );
    }

    // Tip Cont: 'pf' (Persoană Fizică) sau 'pj' (Persoană Juridică)
    $account_type = isset( $_POST['rima_account_type'] ) ? sanitize_text_field( $_POST['rima_account_type'] ) : 'pf';
    update_user_meta( $customer_id, 'rima_account_type', $account_type );

    // Persoană Juridică Fields
    if ( $account_type === 'pj' ) {
        if ( isset( $_POST['billing_company'] ) ) {
            update_user_meta( $customer_id, 'billing_company', sanitize_text_field( $_POST['billing_company'] ) );
        }
        if ( isset( $_POST['billing_cui'] ) ) {
            update_user_meta( $customer_id, 'billing_cui', sanitize_text_field( $_POST['billing_cui'] ) );
        }
        if ( isset( $_POST['billing_reg_com'] ) ) {
            update_user_meta( $customer_id, 'billing_reg_com', sanitize_text_field( $_POST['billing_reg_com'] ) );
        }
        if ( isset( $_POST['billing_iban'] ) ) {
            update_user_meta( $customer_id, 'billing_iban', sanitize_text_field( $_POST['billing_iban'] ) );
        }
        if ( isset( $_POST['billing_bank'] ) ) {
            update_user_meta( $customer_id, 'billing_bank', sanitize_text_field( $_POST['billing_bank'] ) );
        }
    } else {
        // Dacă este PF, ștergem eventualele date rămase
        delete_user_meta( $customer_id, 'billing_company' );
        delete_user_meta( $customer_id, 'billing_cui' );
        delete_user_meta( $customer_id, 'billing_reg_com' );
        delete_user_meta( $customer_id, 'billing_iban' );
        delete_user_meta( $customer_id, 'billing_bank' );
    }

    // Trigger Custom RIMA Email for New Account
    $user = get_userdata( $customer_id );
    $first = get_user_meta( $customer_id, 'billing_first_name', true );
    $last  = get_user_meta( $customer_id, 'billing_last_name', true );
    $name = trim($first . ' ' . $last);
    if(empty($name)) $name = $user->display_name;

    $pass = 'Setată de tine la înregistrare.';
    if ( isset($_POST['account_password']) ) {
        $pass = $_POST['account_password']; // If plain text is available in request
    } elseif ( $password_generated ) {
        $pass = 'A fost generată automat și a fost trimisă în email-ul de sistem (sau folosește opțiunea "Am uitat parola").';
    }

    do_action('rima_student_account_created', $user->user_email, $name, $user->user_login, $pass);
}

// Disable default WooCommerce New Account email (since we send our own 2026 design)
add_filter( 'woocommerce_email_classes', 'rima_disable_wc_new_account_email' );
function rima_disable_wc_new_account_email( $email_classes ) {
    // Dacă vrei să dezactivezi complet mailul WC, decomentează linia de mai jos:
    // unset( $email_classes['WC_Email_Customer_New_Account'] );
    // Dar îl lăsăm momentan activ în cazul în care WC trebuie să trimită parola generată.
    return $email_classes;
}

// -----------------------------------------------------------------------------
// WOOCOMMERCE BILLING / CHECKOUT FIELDS (PF / PJ, IBAN, BANCA)
// -----------------------------------------------------------------------------
add_filter( 'woocommerce_billing_fields', 'rima_custom_billing_fields' );
function rima_custom_billing_fields( $fields ) {
    $fields['rima_account_type'] = array(
        'type'        => 'radio',
        'label'       => __('Tip Cont', 'woocommerce'),
        'required'    => true,
        'class'       => array('form-row-wide', 'rima-checkout-account-type'),
        'options'     => array(
            'pf' => 'Persoană Fizică',
            'pj' => 'Persoană Juridică (Firmă)'
        ),
        'priority'    => 25,
        'default'     => 'pf'
    );

    $fields['billing_cui'] = array(
        'type'        => 'text',
        'label'       => __('CUI / CIF', 'woocommerce'),
        'required'    => false, // JS will make it required if PJ
        'class'       => array('form-row-first', 'rima-pj-field'),
        'priority'    => 35,
    );

    $fields['billing_reg_com'] = array(
        'type'        => 'text',
        'label'       => __('Reg. Comerțului', 'woocommerce'),
        'placeholder' => 'J.../...',
        'required'    => false,
        'class'       => array('form-row-last', 'rima-pj-field'),
        'priority'    => 36,
    );

    $fields['billing_iban'] = array(
        'type'        => 'text',
        'label'       => __('IBAN', 'woocommerce'),
        'placeholder' => 'RO...',
        'required'    => false,
        'class'       => array('form-row-first', 'rima-pj-field', 'rima-checkout-iban'),
        'priority'    => 37,
    );

    $fields['billing_bank'] = array(
        'type'        => 'text',
        'label'       => __('Banca', 'woocommerce'),
        'required'    => false,
        'class'       => array('form-row-last', 'rima-pj-field', 'rima-checkout-bank'),
        'custom_attributes' => array('readonly' => 'readonly'),
        'priority'    => 38,
    );

    if(isset($fields['billing_company'])) {
        $fields['billing_company']['class'] = array('form-row-wide', 'rima-pj-field');
        $fields['billing_company']['priority'] = 30;
    }

    return $fields;
}

// Validare server-side pentru Checkout
add_action( 'woocommerce_checkout_process', 'rima_checkout_fields_validation' );
function rima_checkout_fields_validation() {
    if ( isset($_POST['rima_account_type']) && $_POST['rima_account_type'] === 'pj' ) {
        if ( empty( $_POST['billing_company'] ) ) {
            wc_add_notice( __( 'Vă rugăm introduceți Numele Companiei.', 'woocommerce' ), 'error' );
        }
        if ( empty( $_POST['billing_cui'] ) ) {
            wc_add_notice( __( 'Vă rugăm introduceți CUI / CIF.', 'woocommerce' ), 'error' );
        }
    }
}

// Injectează scriptul de toggling și detecție IBAN în footer-ul paginii Checkout / My Account
add_action( 'wp_footer', 'rima_checkout_fields_js' );
function rima_checkout_fields_js() {
    if ( is_checkout() || is_account_page() ) {
        ?>
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            var accountTypeRadios = document.querySelectorAll('input[name="rima_account_type"]');
            var pjFields = document.querySelectorAll('.rima-pj-field');
            var companyInput = document.querySelector('input[name="billing_company"]');
            var cuiInput = document.querySelector('input[name="billing_cui"]');
            
            function togglePjFields() {
                var checkedRadio = document.querySelector('input[name="rima_account_type"]:checked');
                if(!checkedRadio) return;
                var isPj = checkedRadio.value === 'pj';
                
                pjFields.forEach(function(el) {
                    if(isPj) {
                        el.style.display = 'block';
                        el.classList.remove('rima-hidden');
                    } else {
                        el.style.display = 'none';
                        el.classList.add('rima-hidden');
                    }
                });

                if(companyInput && cuiInput) {
                    if(isPj) {
                        companyInput.closest('.form-row').classList.add('validate-required');
                        cuiInput.closest('.form-row').classList.add('validate-required');
                    } else {
                        companyInput.closest('.form-row').classList.remove('validate-required');
                        cuiInput.closest('.form-row').classList.remove('validate-required');
                    }
                }
            }

            if(accountTypeField) {
                // Initialize pe jQuery change (pt Select2 de la Woo) și native change
                if (typeof jQuery !== 'undefined') {
                    jQuery('select[name="rima_account_type"]').on('change', togglePjFields);
                }
                accountTypeField.addEventListener('change', togglePjFields);
                togglePjFields();
            }

            var ibanField = document.querySelector('input[name="billing_iban"]');
            var bankField = document.querySelector('input[name="billing_bank"]');
            
            function detectBankCheckout(iban) {
                if(!bankField) return;
                let cleanIban = iban.replace(/\s+/g, '').toUpperCase();
                if (cleanIban.length >= 8 && cleanIban.startsWith('RO')) {
                    const bankCode = cleanIban.substring(4, 8);
                    const banks = {
                        'BTRL': 'Banca Transilvania',
                        'INGB': 'ING Bank',
                        'RZBR': 'Raiffeisen Bank',
                        'BREL': 'Libra Internet Bank',
                        'BRDE': 'BRD Groupe Societe Generale',
                        'RNCB': 'Banca Comerciala Romana (BCR)',
                        'UGBI': 'Garanti Bank',
                        'TREZ': 'Trezoreria Statului',
                        'OTPV': 'OTP Bank Romania',
                        'BACX': 'UniCredit Bank',
                        'CECE': 'CEC Bank',
                        'BACA': 'Alpha Bank',
                        'CRDZ': 'Credito Emiliano',
                        'BROM': 'Banca Romaneasca',
                        'MIRO': 'ProCredit Bank',
                        'BNPA': 'BNP Paribas',
                        'CITI': 'Citibank Europe',
                        'EXIM': 'EximBank',
                        'CARP': 'Banca Comerciala Intesa Sanpaolo',
                        'PORL': 'Porsche Bank',
                        'FNNB': 'First Bank',
                        'VIST': 'Vista Bank'
                    };
                    bankField.value = banks[bankCode] ? banks[bankCode] : 'Bancă Necunoscută (' + bankCode + ')';
                } else {
                    bankField.value = '';
                }
            }

            if(ibanField) {
                ibanField.addEventListener('input', function() { detectBankCheckout(this.value); });
                detectBankCheckout(ibanField.value); // Run on load
            }
        });
        </script>
        <style>
            #billing_bank { background: rgba(0,0,0,0.05); cursor: not-allowed; opacity: 0.8; }
            .rima-hidden { display: none !important; }
            
            /* Modern Payment Methods Styling */
            .woocommerce-checkout #payment ul.payment_methods {
                padding: 0 !important;
                border: none !important;
                background: transparent !important;
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            .woocommerce-checkout #payment ul.payment_methods li.wc_payment_method {
                background: rgba(255, 255, 255, 0.05) !important;
                border: 1px solid rgba(255, 255, 255, 0.1) !important;
                border-radius: 8px;
                padding: 15px !important;
                transition: all 0.3s ease;
                display: flex;
                flex-direction: column;
            }
            .woocommerce-checkout #payment ul.payment_methods li.wc_payment_method > label {
                font-weight: 600 !important;
                color: var(--rima-lp-text, #fff) !important;
                cursor: pointer;
                display: flex;
                align-items: center;
                gap: 10px;
                margin: 0 !important;
            }
            .woocommerce-checkout #payment ul.payment_methods li.wc_payment_method input[type="radio"] {
                appearance: none;
                width: 18px;
                height: 18px;
                border: 2px solid rgba(255,255,255,0.3);
                border-radius: 50%;
                margin: 0;
                position: relative;
                outline: none;
                transition: 0.2s;
            }
            .woocommerce-checkout #payment ul.payment_methods li.wc_payment_method input[type="radio"]:checked {
                border-color: #991b1b;
            }
            .woocommerce-checkout #payment ul.payment_methods li.wc_payment_method input[type="radio"]:checked::after {
                content: '';
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 8px;
                height: 8px;
                background: #991b1b;
                border-radius: 50%;
            }
            .woocommerce-checkout #payment ul.payment_methods li.wc_payment_method:focus-within,
            .woocommerce-checkout #payment ul.payment_methods li.wc_payment_method:hover {
                border-color: rgba(255,255,255,0.3) !important;
                background: rgba(255, 255, 255, 0.08) !important;
            }
            .woocommerce-checkout #payment div.payment_box {
                background: transparent !important;
                padding: 10px 0 0 28px !important;
                margin: 0 !important;
                color: rgba(255,255,255,0.7) !important;
                font-size: 13px;
                border: none !important;
            }
            .woocommerce-checkout #payment div.payment_box::before { display: none !important; }
            .woocommerce-checkout #payment {
                background: transparent !important;
                border: none !important;
                padding: 0 !important;
            }
            .woocommerce-checkout #payment .place-order {
                background: transparent !important;
                padding: 20px 0 0 0 !important;
            }
        </style>
        <?php
    }
}

// -----------------------------------------------------------------------------
// SAVE CHECKOUT CUSTOM FIELDS TO ORDER META
// -----------------------------------------------------------------------------
add_action( 'woocommerce_checkout_update_order_meta', 'rima_custom_checkout_field_update_order_meta' );
function rima_custom_checkout_field_update_order_meta( $order_id ) {
    if ( ! empty( $_POST['rima_account_type'] ) ) {
        update_post_meta( $order_id, 'rima_account_type', sanitize_text_field( $_POST['rima_account_type'] ) );
    }
    if ( ! empty( $_POST['billing_cui'] ) ) {
        update_post_meta( $order_id, '_billing_cui', sanitize_text_field( $_POST['billing_cui'] ) );
    }
    if ( ! empty( $_POST['billing_reg_com'] ) ) {
        update_post_meta( $order_id, '_billing_reg_com', sanitize_text_field( $_POST['billing_reg_com'] ) );
    }
    if ( ! empty( $_POST['billing_iban'] ) ) {
        update_post_meta( $order_id, '_billing_iban', sanitize_text_field( $_POST['billing_iban'] ) );
    }
    if ( ! empty( $_POST['billing_bank'] ) ) {
        update_post_meta( $order_id, '_billing_bank', sanitize_text_field( $_POST['billing_bank'] ) );
    }
}

// -----------------------------------------------------------------------------
// PERMITE ACHIZIȚIA MULTIPLĂ (PENTRU FIRME / GRUPURI)
// -----------------------------------------------------------------------------
add_filter( 'woocommerce_is_sold_individually', 'rima_allow_multiple_courses', 10, 2 );
function rima_allow_multiple_courses( $sold_individually, $product ) {
    // Permitem cantitate > 1 pentru a putea fi achiziționate de firme (mai multe licențe)
    return false;
}


