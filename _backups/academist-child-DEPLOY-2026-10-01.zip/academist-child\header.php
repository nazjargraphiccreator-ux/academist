<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <?php
    /**
     * academist_elated_action_header_meta hook
     *
     * @see academist_elated_header_meta() - hooked with 10
     * @see academist_elated_user_scalable_meta - hooked with 10
     * @see academist_core_set_open_graph_meta - hooked with 10
     */
    do_action( 'academist_elated_action_header_meta' );

    wp_head(); ?>
</head>

<body <?php body_class(); ?> itemscope itemtype="http://schema.org/WebPage">
    <script>
    /* RIMA: Nuke Academist parent theme injected elements immediately */
    (function() {
        function rimaKillParentElements() {
            var selectors = [
                '.eltdf-mobile-header',
                '#eltdf-mobile-header',
                '.eltdf-mobile-nav',
                '.eltdf-title-holder',
                '.eltdf-title',
                '.eltdf-side-menu-slide'
            ];
            selectors.forEach(function(sel) {
                var els = document.querySelectorAll(sel);
                els.forEach(function(el) { el.parentNode && el.parentNode.removeChild(el); });
            });
        }
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', rimaKillParentElements);
        } else {
            rimaKillParentElements();
        }
        /* Also run at end of body for any late injections */
        window.addEventListener('load', rimaKillParentElements);
    })();
    </script>
    <?php
    /**
     * academist_elated_action_after_body_tag hook
     *
     * @see academist_elated_get_side_area() - hooked with 10
     * @see academist_elated_smooth_page_transitions() - hooked with 10
     */
    do_action( 'academist_elated_action_after_body_tag' ); ?>

    <div class="eltdf-wrapper">
        <div class="eltdf-wrapper-inner">
            <!-- RIMA GLOBAL HEADER BUILDER -->
            <header id="rima-global-header" class="rima-site-header">
                <div class="rima-container">
                    <div class="rima-header-inner">
                        <!-- LOGO -->
                        <div class="rima-header-logo">
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                                <?php
                                $custom_logo_id = get_theme_mod( 'custom_logo' );
                                $logo_img = wp_get_attachment_image_src( $custom_logo_id , 'full' );
                                if ( has_custom_logo() ) {
                                    echo '<img src="' . esc_url( $logo_img[0] ) . '" alt="' . esc_attr(get_bloginfo( 'name' )) . '">';
                                } else {
                                    echo '<span style="color:white; font-size:24px; font-weight:bold;">'.get_bloginfo('name').'</span>';
                                }
                                ?>
                            </a>
                        </div>
                        
                        <!-- DESKTOP NAV -->
                        <nav class="rima-header-nav">
                            <?php
                            wp_nav_menu( array(
                                'theme_location' => 'main-navigation',
                                'menu_id'        => 'primary-menu',
                                'fallback_cb'    => false,
                            ) );
                            ?>
                        </nav>

                        <!-- TOOLS & CTA -->
                        <div class="rima-header-tools">
                            <?php
                            $my_account_link = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('myaccount') : site_url();
                            $login_link = $my_account_link;

                            if ( is_user_logged_in() ) {
                                $current_user = wp_get_current_user();
                                $avatar_url = get_user_meta( $current_user->ID, 'social_profile_image', true ) ?: get_avatar_url( $current_user->ID, array( 'size' => 80 ) );
                                ?>
                                <a href="<?php echo esc_url($my_account_link); ?>" class="rima-btn rima-btn-secondary" style="border-radius: 999px; padding: 0.5rem 1rem;">
                                    <img src="<?php echo esc_url($avatar_url); ?>" alt="Avatar" style="width:24px; height:24px; border-radius:50%; margin-right:8px;">
                                    Dashboard
                                </a>
                                <?php
                            } else {
                                ?>
                                <a href="<?php echo esc_url($login_link); ?>" class="rima-btn rima-btn-secondary" style="color: white !important; border-color: rgba(255,255,255,0.2);">Login</a>
                                <a href="<?php echo esc_url(site_url('/our-courses/')); ?>" class="rima-btn rima-btn-primary">Get Started</a>
                                <?php
                            }
                            
                            // Cart Icon
                            if ( class_exists( 'WooCommerce' ) ) {
                                $cart_count = WC()->cart->get_cart_contents_count();
                                ?>
                                <a href="#" class="rima-header-cart" id="rima-header-cart-toggle">
                                    <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
                                    <span class="rima-mob-cart-badge"><?php echo $cart_count; ?></span>
                                </a>
                                <?php
                            }
                            ?>
                            
                            <!-- MOBILE TOGGLE -->
                            <button class="rima-mobile-toggle" id="rima-mobile-menu-btn" aria-label="Menu">
                                <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
                            </button>
                        </div>
                    </div>
                </div>
            </header>

            <!-- MOBILE DRAWER -->
            <div class="rima-drawer-overlay" id="rima-mobile-overlay"></div>
            <div class="rima-mobile-drawer" id="rima-mobile-drawer">
                <div class="rima-drawer-header">
                    <img src="<?php echo esc_url( $logo_img[0] ?? '' ); ?>" alt="Rima Logo" style="height:35px;">
                    <button class="rima-drawer-close" id="rima-mobile-close">
                        <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                    </button>
                </div>
                <div class="rima-drawer-content">
                    <nav class="rima-drawer-nav">
                        <?php
                        wp_nav_menu( array(
                            'theme_location' => 'main-navigation',
                            'fallback_cb'    => false,
                        ) );
                        ?>
                    </nav>
                </div>
                <div class="rima-drawer-footer">
                    <?php if ( !is_user_logged_in() ) : ?>
                        <a href="<?php echo esc_url($login_link); ?>" class="rima-btn rima-btn-secondary" style="color:white!important; border-color:white; width:100%;">Login</a>
                        <a href="<?php echo esc_url(site_url('/our-courses/')); ?>" class="rima-btn rima-btn-primary" style="width:100%;">Get Started</a>
                    <?php else: ?>
                        <a href="<?php echo esc_url($my_account_link); ?>" class="rima-btn rima-btn-primary" style="width:100%;">Dashboard</a>
                        <a href="<?php echo wp_logout_url( site_url() ); ?>" class="rima-btn rima-btn-secondary" style="color:white!important; border-color:white; width:100%;">Logout</a>
                    <?php endif; ?>
                </div>
            </div>

            <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Header Scroll State
                const header = document.getElementById('rima-global-header');
                window.addEventListener('scroll', () => {
                    if (window.scrollY > 50) {
                        header.classList.add('is-scrolled');
                    } else {
                        header.classList.remove('is-scrolled');
                    }
                });

                // Mobile Drawer
                const menuBtn = document.getElementById('rima-mobile-menu-btn');
                const closeBtn = document.getElementById('rima-mobile-close');
                const drawer = document.getElementById('rima-mobile-drawer');
                const overlay = document.getElementById('rima-mobile-overlay');

                function toggleMenu() {
                    drawer.classList.toggle('is-open');
                    overlay.classList.toggle('is-open');
                    document.body.style.overflow = drawer.classList.contains('is-open') ? 'hidden' : '';
                }

                if(menuBtn) menuBtn.addEventListener('click', toggleMenu);
                if(closeBtn) closeBtn.addEventListener('click', toggleMenu);
                if(overlay) overlay.addEventListener('click', toggleMenu);

                // Cart toggle existing logic
                var cartBtn = document.getElementById('rima-header-cart-toggle');
                if (cartBtn) {
                    cartBtn.addEventListener('click', function(e) {
                        e.preventDefault();
                        var sc = document.getElementById('rima-side-cart');
                        var overlayCart = document.getElementById('rima-side-cart-overlay');
                        if(sc) sc.classList.add('rima-cart-open');
                        if(overlayCart) overlayCart.classList.add('rima-cart-open');
                    });
                }
            });
            </script>
            
            <?php
            /**
             * academist_elated_action_after_header_area hook
             *
             * @see academist_elated_get_mobile_header() - hooked with 10
             * @see academist_elated_get_title() - hooked with 20
             */
            do_action( 'academist_elated_action_after_header_area' ); ?>
            
            <div class="eltdf-content" <?php academist_elated_content_elem_style_attr(); ?>>
                <div class="eltdf-content-inner">
